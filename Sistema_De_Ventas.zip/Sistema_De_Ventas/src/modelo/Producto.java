package modelo;
/**
 *
 * @author Artur
 */
public class Producto {
    
    private int idProcducto, cantidad, porcentajeIVA, idCategoria, estado;
    private String nombre, descripcion, categoria;
    private float precio;

    public Producto() {
        idProcducto = 0;
        nombre = "";
        cantidad = 0;
        precio = 0f;
        descripcion = "";
        porcentajeIVA = 0;
        idCategoria = 0;
        estado=0;
    }

    public Producto(int idProcducto, int cantidad, int porcentajeIVA, int idCategoria, int estado, String nombre, String descripcion, String categoria, float precio) {
        this.idProcducto = idProcducto;
        this.cantidad = cantidad;
        this.porcentajeIVA = porcentajeIVA;
        this.idCategoria = idCategoria;
        this.estado = estado;
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.categoria = categoria;
        this.precio = precio;
    }

    public int getIdProcducto() {
        return idProcducto;
    }

    public void setIdProcducto(int idProcducto) {
        this.idProcducto = idProcducto;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public int getPorcentajeIVA() {
        return porcentajeIVA;
    }

    public void setPorcentajeIVA(int porcentajeIVA) {
        this.porcentajeIVA = porcentajeIVA;
    }

    public int getIdCategoria() {
        return idCategoria;
    }

    public void setIdCategoria(int idCategoria) {
        this.idCategoria = idCategoria;
    }

    public int getEstado() {
        return estado;
    }

    public void setEstado(int estado) {
        this.estado = estado;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public float getPrecio() {
        return precio;
    }

    public void setPrecio(float precio) {
        this.precio = precio;
    }  
}
