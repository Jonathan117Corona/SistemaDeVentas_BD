package modelo;

/**
 *
 * @author jonat
 */
public class Categoria {
    
   private int idCategoria, estado;
   private String descripcion;

    public Categoria() {
        this.idCategoria = 0;
        this.estado = 0;
        this.descripcion = "";
    }

    public Categoria(int idCategoria, String descripcion, int estado) {
        this.idCategoria = idCategoria;
        this.estado = estado;
        this.descripcion = descripcion;
    }

    public int getIdCategoria() {
        return idCategoria;
    }

    public void setIdCategoria(int idCategoria) {
        this.idCategoria = idCategoria;
    }

    public int getEstado() {
        return estado;
    }

    public void setEstado(int estado) {
        this.estado = estado;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
}
