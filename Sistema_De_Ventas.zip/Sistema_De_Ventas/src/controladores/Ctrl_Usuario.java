package controladores;

import conexion.Conexion_BD;
import modelo.Usuario;
import java.sql.*;

/**
 *
 * @author Edgar JPC (Yacu)
 */
public class Ctrl_Usuario {

    //Metodo para Iniciar Sesion
    public boolean loginUser(Usuario objeto) {   
        boolean resp = false;
        Connection cn = Conexion_BD.conectar();
        String sql = "SELECT usuario, password FROM tb_usuario WHERE usuario = '" + objeto.getUsuario() + "' and password = '" + objeto.getPassword() + "'";
        Statement st;
        
        try {
            st = (Statement) cn.createStatement();
            ResultSet rs = st.executeQuery(sql);

            while (rs.next()) {
                resp = true;
            }
        } catch (SQLException e) {
            System.out.println("Error al Iniciar Sesion");
        }
        return resp;
    }
    
    //Metodo para consultar si el usuario ya esta registrado en la BBDD   
    public boolean existeUsuario(String usuario) {
        boolean respuesta = false;
        String sql = "SELECT usuario FROM tb_usuario WHERE usuario = '" + usuario + "';";
        Statement st;
        try {
            Connection cn = conexion.Conexion_BD.conectar();
            st = cn.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                respuesta = true;
            }
        } catch (SQLException e) {
            System.out.println("Error al consultar usuario: " + e);
        }
        return respuesta;
    }

    //Metodo para guardar un nuevo usuario
    public boolean guardar(Usuario objeto) {
        boolean respuesta = false;
        Connection cn = conexion.Conexion_BD.conectar();
        try {
            PreparedStatement consulta = cn.prepareStatement("INSERT INTO tb_usuario VALUES(?,?,?,?,?,?,?)");
            consulta.setInt(1, 0);//id
            consulta.setString(2, objeto.getNombre());
            consulta.setString(3, objeto.getApellido());
            consulta.setString(4, objeto.getUsuario());
            consulta.setString(5, objeto.getPassword());
            consulta.setString(6, objeto.getTelefono());
            consulta.setInt(7, objeto.getEstado());
            if (consulta.executeUpdate() > 0) {
                respuesta = true;
            }
            cn.close();
        } catch (SQLException e) {
            System.out.println("Error al guardar usuario: " + e);
        }
        return respuesta;
    }
    
    //Metodo para actualizar un usuario
    public boolean actualizar(Usuario objeto, int idUsuario) {
        
        boolean respuesta = false;
        Connection cn = conexion.Conexion_BD.conectar();
        
        try {
            PreparedStatement consulta = cn.prepareStatement("UPDATE tb_usuario SET nombre=?, apellido = ?, usuario = ?, password= ?, telefono = ?, estado = ? WHERE idUsuario ='" + idUsuario + "'");
            consulta.setString(1, objeto.getNombre());
            consulta.setString(2, objeto.getApellido());
            consulta.setString(3, objeto.getUsuario());
            consulta.setString(4, objeto.getPassword());
            consulta.setString(5, objeto.getTelefono());
            consulta.setInt(6, objeto.getEstado());

            if (consulta.executeUpdate() > 0) {
                respuesta = true;
            }
            cn.close();
        } catch (SQLException e) {
            System.out.println("Error al actualizar usuario: " + e);
        }
        return respuesta;
    }
    
    //Metodo para eliminar un usuario
    public boolean eliminar(int idUsuario) {
        boolean respuesta = false;
        Connection cn = conexion.Conexion_BD.conectar();
        try {
            PreparedStatement consulta = cn.prepareStatement(
                    "DELETE FROM tb_usuario WHERE idUsuario ='" + idUsuario + "'");
            consulta.executeUpdate();

            if (consulta.executeUpdate() > 0) {
                respuesta = true;
            }
            cn.close();
        } catch (SQLException e) {
            System.out.println("Error al eliminar usuario: " + e);
        }
        return respuesta;
    }

}
