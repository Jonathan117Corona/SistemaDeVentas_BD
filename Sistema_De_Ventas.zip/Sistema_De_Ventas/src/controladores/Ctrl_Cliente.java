package controladores;

import java.sql.Connection;
import java.sql.PreparedStatement;
import modelo.Cliente;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 *
 * @author Edgar JPC (Yacu)
 */
public class Ctrl_Cliente {

    //Metodo para guardar un nuevo cliente
    public boolean guardar(Cliente objeto) {
        boolean respuesta = false;
        Connection cn = conexion.Conexion_BD.conectar();
        try {
            PreparedStatement consulta = (PreparedStatement) cn.prepareStatement("INSERT INTO tb_cliente VALUES(?,?,?,?,?,?,?)");
            consulta.setInt(1, 0);//id
            consulta.setString(2, objeto.getNombre());
            consulta.setString(3, objeto.getApellido());
            consulta.setString(4, objeto.getCedula());
            consulta.setString(5, objeto.getTelefono());
            consulta.setString(6, objeto.getDireccion());
            consulta.setInt(7, objeto.getEstado());
            if (consulta.executeUpdate() > 0) {
                respuesta = true;
            }
            cn.close();
        } catch (SQLException e) {
            System.out.println("Error al guardar cliente: " + e);
        }
        return respuesta;
    }

    //Metodo para consultar si el producto ya esta registrado en la BBDD
    public boolean existeCliente(String cedula) {
        boolean respuesta = false;
        String sql = "SELECT cedula FROM tb_cliente WHERE cedula = '" + cedula + "';";
        Statement st;
        try {
            Connection cn = conexion.Conexion_BD.conectar();
            st = (Statement) cn.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                respuesta = true;
            }
        } catch (SQLException e) {
            System.out.println("Error al consultar cliente: " + e);
        }
        return respuesta;
    }

    //Metodo para actualizar un cliente
    public boolean actualizar(Cliente objeto, int idCliente) {
        boolean respuesta = false;
        Connection cn = conexion.Conexion_BD.conectar();
        try {

            PreparedStatement consulta = (PreparedStatement) cn.prepareStatement("UPDATE tb_cliente SET nombre=?, apellido = ?, cedula = ?, telefono= ?, direccion = ?, estado = ? WHERE idCliente ='" + idCliente + "'");
            consulta.setString(1, objeto.getNombre());
            consulta.setString(2, objeto.getApellido());
            consulta.setString(3, objeto.getCedula());
            consulta.setString(4, objeto.getTelefono());
            consulta.setString(5, objeto.getDireccion());
            consulta.setInt(6, objeto.getEstado());

            if (consulta.executeUpdate() > 0) {
                respuesta = true;
            }
            cn.close();
        } catch (SQLException e) {
            System.out.println("Error al actualizar cliente: " + e);
        }
        return respuesta;
    }
    
    //Metodo para eliminar a un cliente
    public boolean eliminar(int idCliente){
        
        boolean respuesta = false;
        Connection cn = conexion.Conexion_BD.conectar();
        try {
            PreparedStatement consulta = (PreparedStatement) cn.prepareStatement(
                    "DELETE FROMtb_cliente WHERE idCliente ='" + idCliente + "'");
            consulta.executeUpdate();

            if (consulta.executeUpdate() > 0) {
                respuesta = true;
            }
            cn.close();
        } catch (SQLException e) {
            System.out.println("Error al eliminar cliente: " + e);
        }
        return respuesta;
    }

}