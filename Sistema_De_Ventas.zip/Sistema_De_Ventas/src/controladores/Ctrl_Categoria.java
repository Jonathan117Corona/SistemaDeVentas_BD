package controladores;

import modelo.Categoria;
import java.sql.*;
import javax.swing.JOptionPane;

/**
 *
 * @author jonat
 */
public class Ctrl_Categoria {

    //Metodo para registrar una categoria
    public boolean guardar(Categoria objeto) {
        boolean resp = false;
        Connection cn = conexion.Conexion_BD.conectar();
        try {
            PreparedStatement consulta = cn.prepareStatement("INSERT INTO tb_categoria VALUES (?,?,?)");
            consulta.setInt(1, 0);
            consulta.setString(2, objeto.getDescripcion());
            consulta.setInt(3, objeto.getEstado());
            if (consulta.executeUpdate() > 0) {
                resp = true;
            }
            cn.close();
        } catch (SQLException e) {
            System.out.println("Error al guardar categoria");
        }

        return resp;
    }

    //Metodo para consultar si existe la categoria
    public boolean existeCategoria(String categoria) {

        boolean resp = false;
        String SQL = "SELECT descripcion FROM tb_categoria WHERE descripcion = " + categoria + " ;";
        Statement st;

        try {
            Connection cn = conexion.Conexion_BD.conectar();
            st = cn.createStatement();
            ResultSet rs = st.executeQuery(SQL);
            while (rs.next()) {
                resp = true;
            }
        } catch (SQLException e) {
            System.out.println("Error al consultar categoria");
        }
        return resp;
    }
    
    
    //Metodo para ACTUALIZAR
    public boolean actualizar(Categoria objeto, int idCategoria) {
        boolean resp = false;
        Connection cn = conexion.Conexion_BD.conectar();
        try {
            PreparedStatement consulta = cn.prepareStatement("UPDATE tb_categoria SET descripcion = ? WHERE idCategoria= '"+idCategoria+"'");
            consulta.setString(1, objeto.getDescripcion());
            if(consulta.executeUpdate()>0){
                resp=true;
            }
            
            cn.close();

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al actualizar la categoria");
        }

        return resp;
    }
    
    //Metodo BORRAR
    public boolean borrar(int idCategoria) {
        boolean resp = false;
        Connection cn = conexion.Conexion_BD.conectar();
        try {
            PreparedStatement consulta = cn.prepareStatement("DELETE FROM tb_categoria WHERE idCategoria= '"+idCategoria+"'");
            consulta.executeUpdate();
            if(consulta.executeUpdate()>0){
                resp=true;
            }
            
            cn.close();

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al eliminar la categoria");
        }

        return resp;
    }

}
