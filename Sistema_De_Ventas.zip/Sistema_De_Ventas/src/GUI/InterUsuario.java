package GUI;

import controladores.Ctrl_Usuario;
import java.awt.Dimension;
import javax.swing.JOptionPane;
import modelo.Usuario;

/**
 *
 * @author Edgar JPC (Yacu)
 */
public class InterUsuario extends javax.swing.JInternalFrame {

    //int obtenerID_Categoria = 0;
    public InterUsuario() {
        initComponents();
        setSize(new Dimension(400, 300));
        setTitle("Nuevo Usuario");
        psw_Contraseña.setVisible(true);
        txt_pswVisible.setVisible(false);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lbl_titulo = new javax.swing.JLabel();
        lbl_Usuario = new javax.swing.JLabel();
        lbl_Apellido = new javax.swing.JLabel();
        lbl_Contraseña = new javax.swing.JLabel();
        lbl_Telefono = new javax.swing.JLabel();
        lbl_Nombre = new javax.swing.JLabel();
        txt_Nombre = new javax.swing.JTextField();
        txt_Usuario = new javax.swing.JTextField();
        txt_Apellido = new javax.swing.JTextField();
        txt_Telefono = new javax.swing.JTextField();
        psw_Contraseña = new javax.swing.JPasswordField();
        txt_pswVisible = new javax.swing.JTextField();
        chekB_verClave = new javax.swing.JCheckBox();
        btnGuardar = new javax.swing.JButton();
        lbl_Walpapaer = new javax.swing.JLabel();

        setClosable(true);
        setIconifiable(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lbl_titulo.setFont(new java.awt.Font("Impact", 0, 18)); // NOI18N
        lbl_titulo.setForeground(new java.awt.Color(255, 255, 255));
        lbl_titulo.setText("Nuevo Usuario");
        getContentPane().add(lbl_titulo, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 10, -1, -1));

        lbl_Usuario.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 14)); // NOI18N
        lbl_Usuario.setForeground(new java.awt.Color(255, 255, 255));
        lbl_Usuario.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lbl_Usuario.setText("Usuario:");
        getContentPane().add(lbl_Usuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 110, 80, -1));

        lbl_Apellido.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 14)); // NOI18N
        lbl_Apellido.setForeground(new java.awt.Color(255, 255, 255));
        lbl_Apellido.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lbl_Apellido.setText("Apellido:");
        getContentPane().add(lbl_Apellido, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 80, 80, -1));

        lbl_Contraseña.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 14)); // NOI18N
        lbl_Contraseña.setForeground(new java.awt.Color(255, 255, 255));
        lbl_Contraseña.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lbl_Contraseña.setText("Contraseña:");
        getContentPane().add(lbl_Contraseña, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 140, 80, -1));

        lbl_Telefono.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 14)); // NOI18N
        lbl_Telefono.setForeground(new java.awt.Color(255, 255, 255));
        lbl_Telefono.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lbl_Telefono.setText("Telefono:");
        getContentPane().add(lbl_Telefono, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 170, 80, -1));

        lbl_Nombre.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 14)); // NOI18N
        lbl_Nombre.setForeground(new java.awt.Color(255, 255, 255));
        lbl_Nombre.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lbl_Nombre.setText("Nombre:");
        getContentPane().add(lbl_Nombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 50, 80, -1));

        txt_Nombre.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 12)); // NOI18N
        getContentPane().add(txt_Nombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 50, 170, -1));

        txt_Usuario.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 12)); // NOI18N
        getContentPane().add(txt_Usuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 110, 170, -1));

        txt_Apellido.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 12)); // NOI18N
        getContentPane().add(txt_Apellido, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 80, 170, -1));

        txt_Telefono.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 12)); // NOI18N
        getContentPane().add(txt_Telefono, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 170, 170, -1));

        psw_Contraseña.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 12)); // NOI18N
        getContentPane().add(psw_Contraseña, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 140, 170, -1));

        txt_pswVisible.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 12)); // NOI18N
        getContentPane().add(txt_pswVisible, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 140, 170, -1));

        chekB_verClave.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        chekB_verClave.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                chekB_verClaveMouseClicked(evt);
            }
        });
        chekB_verClave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chekB_verClaveActionPerformed(evt);
            }
        });
        getContentPane().add(chekB_verClave, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 140, 20, 20));

        btnGuardar.setBackground(new java.awt.Color(0, 204, 204));
        btnGuardar.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 12)); // NOI18N
        btnGuardar.setText("Guardar");
        btnGuardar.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarActionPerformed(evt);
            }
        });
        getContentPane().add(btnGuardar, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 210, 90, 30));

        lbl_Walpapaer.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 12)); // NOI18N
        lbl_Walpapaer.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/fondo3.jpg"))); // NOI18N
        getContentPane().add(lbl_Walpapaer, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 390, 270));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarActionPerformed

        if (txt_Nombre.getText().isEmpty() || txt_Apellido.getText().isEmpty() || txt_Usuario.getText().isEmpty()
                || psw_Contraseña.getText().isEmpty() || txt_Telefono.getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Complete todos los campos");

        } else {
            //Validamos si el usuario ya esta registrado:
            Usuario usuario = new Usuario();
            Ctrl_Usuario ctrlUsuario = new Ctrl_Usuario();
            if (!ctrlUsuario.existeUsuario(txt_Usuario.getText().trim())) {
                //Enviamos datos del usuario
                usuario.setNombre(txt_Nombre.getText().trim());
                usuario.setApellido(txt_Apellido.getText().trim());
                usuario.setUsuario(txt_Usuario.getText().trim());
                usuario.setPassword(psw_Contraseña.getText().trim());
                usuario.setTelefono(txt_Telefono.getText().trim());
                usuario.setEstado(1);
                if (ctrlUsuario.guardar(usuario)) {
                    JOptionPane.showMessageDialog(null, "Usuario registrado");
                } else {
                    JOptionPane.showMessageDialog(null, "Error al registrar el usuario");
                }

            } else {
                JOptionPane.showMessageDialog(null, "El usuario ya existe, \npor favro ingrese otro");
            }
        }
        limpiarCampos();
    }//GEN-LAST:event_btnGuardarActionPerformed

    private void chekB_verClaveMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_chekB_verClaveMouseClicked
        // TODO add your handling code here:
        if (chekB_verClave.isSelected() == true) {
            String pass = "";
            char[] passwordIngresado = psw_Contraseña.getPassword();
            for (int i = 0; i < passwordIngresado.length; i++) {
                pass += passwordIngresado[i];
            }
            txt_pswVisible.setText(pass);
            psw_Contraseña.setVisible(false);
            txt_pswVisible.setVisible(true);
        } else {
            String passIngresado = txt_pswVisible.getText().trim();
            psw_Contraseña.setText(passIngresado);
            psw_Contraseña.setVisible(true);
            txt_pswVisible.setVisible(false);
        }
    }//GEN-LAST:event_chekB_verClaveMouseClicked

    private void chekB_verClaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chekB_verClaveActionPerformed
        // TODO add your handling code here:
        if (chekB_verClave.isSelected() == true) {
            String pass = "";
            char[] passwordIngresado = psw_Contraseña.getPassword();
            for (int i = 0; i < passwordIngresado.length; i++) {
                pass += passwordIngresado[i];
            }
            txt_pswVisible.setText(pass);
            psw_Contraseña.setVisible(false);
            txt_pswVisible.setVisible(true);
        } else {
            String passIngresado = txt_pswVisible.getText().trim();
            psw_Contraseña.setText(passIngresado);
            psw_Contraseña.setVisible(true);
            txt_pswVisible.setVisible(false);
        }
    }//GEN-LAST:event_chekB_verClaveActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnGuardar;
    private javax.swing.JCheckBox chekB_verClave;
    private javax.swing.JLabel lbl_Apellido;
    private javax.swing.JLabel lbl_Contraseña;
    private javax.swing.JLabel lbl_Nombre;
    private javax.swing.JLabel lbl_Telefono;
    private javax.swing.JLabel lbl_Usuario;
    private javax.swing.JLabel lbl_Walpapaer;
    private javax.swing.JLabel lbl_titulo;
    private javax.swing.JPasswordField psw_Contraseña;
    private javax.swing.JTextField txt_Apellido;
    private javax.swing.JTextField txt_Nombre;
    private javax.swing.JTextField txt_Telefono;
    private javax.swing.JTextField txt_Usuario;
    private javax.swing.JTextField txt_pswVisible;
    // End of variables declaration//GEN-END:variables

    private void limpiarCampos() {
        txt_Apellido.setText("");
        txt_Telefono.setText("");
        txt_Nombre.setText("");
        txt_Usuario.setText("");
        psw_Contraseña.setText("");
    }
}
