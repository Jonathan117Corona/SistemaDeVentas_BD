package GUI;

import controladores.Ctrl_RegistrarVenta;
import controladores.VentaPDF;
import java.sql.*;
import java.awt.Dimension;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import modelo.CabeceraVenta;
import modelo.DetalleVenta;
import java.util.Date;

/**
 *
 * @author jonat
 */
public class InterFacturacion extends javax.swing.JInternalFrame {

    //modelo de datos
    private DefaultTableModel modeloDatosProductos;
    //lista para el detalle de venta de los productos
    ArrayList<DetalleVenta> listaProductos = new ArrayList<>();
    private DetalleVenta producto;

    private int idProducto = 0, cantidadProductoBBDD = 0, porcentajeIva = 0;
    private String nombre = "";
    private float precioUnitario = 0.0f;

    private int cantidad = 0;//cantidad de productos a comprar
    private float subtotal = 0.0f, descuento = 0.0f, iva = 0.0f, totalPagar = 0.0f;

    private int auxIdDetalle = 1;//id del detalle de venta
    private int idCliente = 0;//id del cliente seleccionado

    //Variables para calculos globales
    private float subtotalGeneral = 0.0f, descuentoGeneral = 0.0f, ivaGeneral = 0.0f, totalPagarGeneral = 0.0f;
    //Fin de variables de calculos globales

    public InterFacturacion() {
        initComponents();
        setTitle("Facturacion");
        setSize(new Dimension(800, 600));
        cargarCliente();
        cargarProductos();
        inicializarTablaProducto();

        //desactivar osea que el usuario  no pueda alterar lo que esta en el txt y el btn  
        txt_efectivo.setEnabled(false);
        btn_calcularCambio.setEnabled(false);

        //Establecemos a los txt por defecto 0.0
        txt_subtotal.setText("0.0");
        txt_IVA.setText("0.0");
        txt_descuento.setText("0.0");
        txt_totalPagar.setText("0.0");
    }

    //Metodo para inicializar la tabla productos
    private void inicializarTablaProducto() {
        modeloDatosProductos = new DefaultTableModel();
        //añadir columnas
        modeloDatosProductos.addColumn("N"); //0
        modeloDatosProductos.addColumn("Nombre");
        modeloDatosProductos.addColumn("Cantidad");
        modeloDatosProductos.addColumn("P. Unitario");
        modeloDatosProductos.addColumn("SubTotal");
        modeloDatosProductos.addColumn("Descuento");
        modeloDatosProductos.addColumn("Iva");
        modeloDatosProductos.addColumn("Total Pagar");
        modeloDatosProductos.addColumn("Accion");//8
        //agregar los datos del modelo a la tabla
        table_productos.setModel(modeloDatosProductos);
    }

    //Metodo para presentar la informacion para la tabla DetalleVenta
    private void listaTablaProductos() {
        this.modeloDatosProductos.setRowCount(listaProductos.size());
        for (int i = 0; i < listaProductos.size(); i++) {
            this.modeloDatosProductos.setValueAt(i + 1, i, 0);
            this.modeloDatosProductos.setValueAt(listaProductos.get(i).getNombre(), i, 1);
            this.modeloDatosProductos.setValueAt(listaProductos.get(i).getCantidad(), i, 2);
            this.modeloDatosProductos.setValueAt(listaProductos.get(i).getPrecioUnitario(), i, 3);
            this.modeloDatosProductos.setValueAt(listaProductos.get(i).getSubTotal(), i, 4);
            this.modeloDatosProductos.setValueAt(listaProductos.get(i).getDescuento(), i, 5);
            this.modeloDatosProductos.setValueAt(listaProductos.get(i).getIva(), i, 6);
            this.modeloDatosProductos.setValueAt(listaProductos.get(i).getTotalPagar(), i, 7);
            this.modeloDatosProductos.setValueAt("Eliminar", i, 8);//aqui luego poner un boton de eliminar
        }
        //añadir al Jtable
        table_productos.setModel(modeloDatosProductos);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lbl_titulo = new javax.swing.JLabel();
        lbl_cliente = new javax.swing.JLabel();
        lbl_producto = new javax.swing.JLabel();
        lbl_cantidad = new javax.swing.JLabel();
        comboBox_Cliente = new javax.swing.JComboBox<>();
        comboBox_Producto = new javax.swing.JComboBox<>();
        txt_clienteBuscar = new javax.swing.JTextField();
        txt_cantidad = new javax.swing.JTextField();
        btn_BuscarCliente = new javax.swing.JButton();
        btn_añadirProducto = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        table_productos = new javax.swing.JTable();
        panel2 = new javax.swing.JPanel();
        lbl_Subtotal = new javax.swing.JLabel();
        lbl_descuento = new javax.swing.JLabel();
        lbl_IVA = new javax.swing.JLabel();
        lbl_totalPagar = new javax.swing.JLabel();
        lbl_totalPagar1 = new javax.swing.JLabel();
        lbl_totalPagar2 = new javax.swing.JLabel();
        txt_subtotal = new javax.swing.JTextField();
        txt_descuento = new javax.swing.JTextField();
        txt_IVA = new javax.swing.JTextField();
        txt_totalPagar = new javax.swing.JTextField();
        txt_efectivo = new javax.swing.JTextField();
        txt_cambio = new javax.swing.JTextField();
        btn_calcularCambio = new javax.swing.JButton();
        btn_registrarVentas = new javax.swing.JButton();
        lbl_Wallpaper = new javax.swing.JLabel();

        setClosable(true);
        setIconifiable(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lbl_titulo.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 24)); // NOI18N
        lbl_titulo.setForeground(new java.awt.Color(255, 255, 255));
        lbl_titulo.setText("Facturacion");
        getContentPane().add(lbl_titulo, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 0, -1, -1));

        lbl_cliente.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 14)); // NOI18N
        lbl_cliente.setForeground(new java.awt.Color(255, 255, 255));
        lbl_cliente.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lbl_cliente.setText("Cliente:");
        getContentPane().add(lbl_cliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 40, 80, -1));

        lbl_producto.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 14)); // NOI18N
        lbl_producto.setForeground(new java.awt.Color(255, 255, 255));
        lbl_producto.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lbl_producto.setText("Producto:");
        getContentPane().add(lbl_producto, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 80, 80, -1));

        lbl_cantidad.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 14)); // NOI18N
        lbl_cantidad.setForeground(new java.awt.Color(255, 255, 255));
        lbl_cantidad.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lbl_cantidad.setText("Cantidad:");
        getContentPane().add(lbl_cantidad, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 80, 80, -1));

        comboBox_Cliente.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 12)); // NOI18N
        comboBox_Cliente.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccione cliente:", "item 1", "item 2", "item 3", "item 4" }));
        getContentPane().add(comboBox_Cliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 40, 170, -1));

        comboBox_Producto.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 12)); // NOI18N
        comboBox_Producto.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccione producto:", "item 1", "item 2", "item 3", "item 4" }));
        getContentPane().add(comboBox_Producto, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 80, 170, -1));

        txt_clienteBuscar.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 12)); // NOI18N
        txt_clienteBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_clienteBuscarActionPerformed(evt);
            }
        });
        getContentPane().add(txt_clienteBuscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(275, 40, 150, 20));

        txt_cantidad.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 12)); // NOI18N
        txt_cantidad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_cantidadActionPerformed(evt);
            }
        });
        getContentPane().add(txt_cantidad, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 80, 60, -1));

        btn_BuscarCliente.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 12)); // NOI18N
        btn_BuscarCliente.setText("Buscar");
        btn_BuscarCliente.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_BuscarCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_BuscarClienteActionPerformed(evt);
            }
        });
        getContentPane().add(btn_BuscarCliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 40, 80, 20));

        btn_añadirProducto.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 12)); // NOI18N
        btn_añadirProducto.setText("Añadir");
        btn_añadirProducto.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_añadirProducto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_añadirProductoActionPerformed(evt);
            }
        });
        getContentPane().add(btn_añadirProducto, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 80, 80, 20));

        jPanel1.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        table_productos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        table_productos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                table_productosMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(table_productos);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 740, 190));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 120, 760, 210));

        panel2.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        panel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lbl_Subtotal.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 12)); // NOI18N
        lbl_Subtotal.setText("Subtotal:");
        panel2.add(lbl_Subtotal, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 20, -1, -1));

        lbl_descuento.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 12)); // NOI18N
        lbl_descuento.setText("Descuento:");
        panel2.add(lbl_descuento, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 50, -1, -1));

        lbl_IVA.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 12)); // NOI18N
        lbl_IVA.setText("IVA:");
        panel2.add(lbl_IVA, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 80, -1, -1));

        lbl_totalPagar.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 12)); // NOI18N
        lbl_totalPagar.setText("Total a pagar:");
        panel2.add(lbl_totalPagar, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 110, -1, -1));

        lbl_totalPagar1.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 12)); // NOI18N
        lbl_totalPagar1.setText("Efectivo:");
        panel2.add(lbl_totalPagar1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 150, -1, -1));

        lbl_totalPagar2.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 12)); // NOI18N
        lbl_totalPagar2.setText("Cambio:");
        panel2.add(lbl_totalPagar2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 180, -1, -1));

        txt_subtotal.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 12)); // NOI18N
        txt_subtotal.setEnabled(false);
        panel2.add(txt_subtotal, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 20, 120, -1));

        txt_descuento.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 12)); // NOI18N
        txt_descuento.setEnabled(false);
        panel2.add(txt_descuento, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 50, 120, -1));

        txt_IVA.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 12)); // NOI18N
        txt_IVA.setEnabled(false);
        panel2.add(txt_IVA, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 80, 120, -1));

        txt_totalPagar.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 12)); // NOI18N
        txt_totalPagar.setEnabled(false);
        panel2.add(txt_totalPagar, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 110, 120, -1));

        txt_efectivo.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 12)); // NOI18N
        panel2.add(txt_efectivo, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 150, 120, -1));

        txt_cambio.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 12)); // NOI18N
        txt_cambio.setEnabled(false);
        panel2.add(txt_cambio, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 180, 120, -1));

        btn_calcularCambio.setBackground(new java.awt.Color(0, 204, 204));
        btn_calcularCambio.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 12)); // NOI18N
        btn_calcularCambio.setText("Calcular Cambio:");
        btn_calcularCambio.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_calcularCambio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_calcularCambioActionPerformed(evt);
            }
        });
        panel2.add(btn_calcularCambio, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 150, 130, 50));

        getContentPane().add(panel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 342, 380, 210));

        btn_registrarVentas.setBackground(new java.awt.Color(0, 204, 204));
        btn_registrarVentas.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 12)); // NOI18N
        btn_registrarVentas.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/impresora.png"))); // NOI18N
        btn_registrarVentas.setText("Registrar Ventas");
        btn_registrarVentas.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_registrarVentas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_registrarVentasActionPerformed(evt);
            }
        });
        getContentPane().add(btn_registrarVentas, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 350, 150, 60));

        lbl_Wallpaper.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/fondo2222.jpg"))); // NOI18N
        lbl_Wallpaper.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        lbl_Wallpaper.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        getContentPane().add(lbl_Wallpaper, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 790, 570));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txt_clienteBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_clienteBuscarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_clienteBuscarActionPerformed

    private void txt_cantidadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_cantidadActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_cantidadActionPerformed

    private void btn_BuscarClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_BuscarClienteActionPerformed
        String clienteBuscar = txt_clienteBuscar.getText().trim();
        Connection cn = conexion.Conexion_BD.conectar();
        String SQL = "SELECT nombre, apellido FROM tb_cliente WHERE cedula = '" + clienteBuscar + "'";
        Statement st;
        try {
            st = cn.createStatement();
            ResultSet rs = st.executeQuery(SQL);

            if (rs.next()) {
                comboBox_Cliente.setSelectedItem(rs.getString("nombre") + " " + rs.getString("apellido"));
            } else {
                comboBox_Cliente.setSelectedItem("Seleccione cliente:");
                JOptionPane.showMessageDialog(null, "¡Cedula de cliente incorrecta o no encontrada!");
            }
            txt_clienteBuscar.setText("");
            cn.close();
        } catch (SQLException e) {
            System.out.println("¡Error al buscar cliente!, " + e);
        }
    }//GEN-LAST:event_btn_BuscarClienteActionPerformed

    private void btn_añadirProductoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_añadirProductoActionPerformed

        String combo = comboBox_Producto.getSelectedItem().toString();
        //validar que seleccione un producto
        if (combo.equalsIgnoreCase("Seleccione producto:")) {
            JOptionPane.showMessageDialog(null, "Seleccione un producto");
        } else {
            //validar que ingrese una cantidad
            if (!txt_cantidad.getText().isEmpty()) {
                //validar que el usuario no ingrese caracteres no numericos
                boolean validacion = validar(txt_cantidad.getText());
                if (validacion == true) {
                    //validar que la cantidad sea mayor a cero
                    if (Integer.parseInt(txt_cantidad.getText()) > 0) {
                        cantidad = Integer.parseInt(txt_cantidad.getText());
                        DatosDelProducto();//ejecutar metodo para obtener datos del producto
                        //validar que la cantidad de productos seleccionado no sea mayor al stock de la base de datos
                        if (cantidad <= cantidadProductoBBDD) {

                            subtotal = precioUnitario * cantidad;
                            totalPagar = subtotal + iva + descuento;

                            //redondear decimales
                            subtotal = Math.round(subtotal * 100) / 100;
                            iva = Math.round(iva * 100) / 100;
                            descuento = Math.round(descuento * 100) / 100;
                            totalPagar = Math.round(totalPagar * 100) / 100;

                            //se crea un nuevo producto
                            producto = new DetalleVenta(auxIdDetalle,//idDetalleVenta
                                    1, //idCabecera
                                    idProducto, nombre, Integer.parseInt(txt_cantidad.getText()), precioUnitario,
                                    subtotal, descuento, iva, totalPagar, 1);
                            //añadir a la lista
                            listaProductos.add(producto);
                            //JOptionPane.showMessageDialog(null, "Producto Agregado");
                            auxIdDetalle++;
                            txt_cantidad.setText("");//limpiar el campo
                            //volver a cargar combo productos
                            cargarProductos();
                            CalcularTotalPagar();
                            //habilitamos el txt y el boton 
                            txt_efectivo.setEnabled(true);
                            btn_calcularCambio.setEnabled(true);

                        } else {
                            JOptionPane.showMessageDialog(null, "La cantidad supera el Stock");
                        }
                    } else {
                        JOptionPane.showMessageDialog(null, "La cantidad no puede ser cero (0) o menos");
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "En la cantidad no se admiten caracteres no numericos");
                }
            } else {
                JOptionPane.showMessageDialog(null, "Ingresa una cantidad de productos");
            }
        }
        listaTablaProductos();
    }//GEN-LAST:event_btn_añadirProductoActionPerformed

    private void btn_calcularCambioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_calcularCambioActionPerformed

        if (!txt_efectivo.getText().isEmpty()) {
            //validamos que el usuario no ingrese otros caracteres no numericos 
            boolean validacion = validarFloat(txt_efectivo.getText());
            if (validacion == true) {
                //validar que el efectivo sea mayor a cero
                float efc = Float.parseFloat(txt_efectivo.getText().trim());
                float top = Float.parseFloat(txt_totalPagar.getText().trim());

                if (efc < top) {
                    JOptionPane.showMessageDialog(null, "El Dinero en efectivo no es suficiente");
                } else {
                    float cambio = (efc - top);
                    float cambi = Math.round(cambio * 100d) / 100;
                    String camb = String.valueOf(cambi);
                    txt_cambio.setText(camb);
                }
            } else {
                JOptionPane.showMessageDialog(null, "No de admiten caracteres no numericos");
            }
        } else {
            JOptionPane.showMessageDialog(null, "Ingrese dinero en efectivo para calcular cambio");
        }
    }//GEN-LAST:event_btn_calcularCambioActionPerformed

    public static int contadorDeVentas = 0;
    private void btn_registrarVentasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_registrarVentasActionPerformed
        CabeceraVenta cabeceraVenta = new CabeceraVenta();
        DetalleVenta detalleVenta = new DetalleVenta();
        Ctrl_RegistrarVenta controlVenta = new Ctrl_RegistrarVenta();

        String fechaActual = "";
        Date date = new Date();
        fechaActual = new SimpleDateFormat("yyyy/MM/dd").format(date);

        if (!comboBox_Cliente.getSelectedItem().equals("Seleccione cliente:")) {
            if (listaProductos.size() > 0) {

                //metodo para obtener el id del cliente
                ObtenerIdCliente();
                //registrar cabecera
                cabeceraVenta.setIdCabeceraventa(0);
                cabeceraVenta.setIdCliente(idCliente);
                cabeceraVenta.setValorPagar(Float.parseFloat(txt_totalPagar.getText()));
                cabeceraVenta.setFechaVenta(fechaActual);
                cabeceraVenta.setEstado(1);

                if (controlVenta.guardar(cabeceraVenta)) {
                    JOptionPane.showMessageDialog(null, "¡Venta Registrada!");
                    contadorDeVentas++;
                    //Generamos la factura de venta mio
//                    PDF pdf = new PDF();
//                    pdf.datosCliente(idCliente);
//                    pdf.generarFacturaPDF();
                    //Prueba para generar factura de venta
                      VentaPDF pdf = new VentaPDF();
                      pdf.DatosCliente(idCliente);
                      pdf.generarFacturaPDF();

                    //Guardar detalle de venta       
                    for (DetalleVenta elemento : listaProductos) {
                        detalleVenta.setIdDetalleVenta(0);
                        detalleVenta.setIdCabeceraVenta(0);
                        detalleVenta.setIdProducto(elemento.getIdProducto());
                        detalleVenta.setCantidad(elemento.getCantidad());
                        detalleVenta.setPrecioUnitario(elemento.getPrecioUnitario());
                        detalleVenta.setSubTotal(elemento.getSubTotal());
                        detalleVenta.setDescuento(elemento.getDescuento());
                        detalleVenta.setIva(elemento.getIva());
                        detalleVenta.setTotalPagar(elemento.getTotalPagar());
                        detalleVenta.setEstado(1);

                        if (controlVenta.guardarDetalle(detalleVenta)) {
                            txt_subtotal.setText("0.0");
                            txt_IVA.setText("0.0");
                            txt_descuento.setText("0.0");
                            txt_totalPagar.setText("0.0");
                            txt_efectivo.setText("");
                            txt_cambio.setText("0.0");
                            auxIdDetalle = 1;
                            cargarCliente();
                            RestarStockProductos(elemento.getIdProducto(), elemento.getCantidad()); //restar stock
                        } else {
                            JOptionPane.showMessageDialog(null, "¡Error al guardar detalle de venta!");
                        }
                    }
                    //vaciamos la lista
                    listaProductos.clear();
                    listaTablaProductos();

                } else {
                    JOptionPane.showMessageDialog(null, "¡Error al guardar cabecera de venta!");
                }
            } else {
                JOptionPane.showMessageDialog(null, "¡Seleccione un producto!");
            }
        } else {
            JOptionPane.showMessageDialog(null, "¡Seleccione un cliente!");
        }


    }//GEN-LAST:event_btn_registrarVentasActionPerformed

    int idArrayList = 0;
    private void table_productosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_table_productosMouseClicked
        int fila_point = table_productos.rowAtPoint(evt.getPoint());
        int columna_point = 0;
        if (fila_point > -1) {
            idArrayList = (int) modeloDatosProductos.getValueAt(fila_point, columna_point);
        }
        int opcion = JOptionPane.showConfirmDialog(null, "¿Eliminar Producto?");

        //opciones de confir dialog - (si = 0; no = 1; cancel = 2; close = -1)
        switch (opcion) {
            case 0: //presione si
                listaProductos.remove(idArrayList - 1);
                CalcularTotalPagar();
                this.listaTablaProductos();
                break;
            case 1: //presione no
                break;
            default://sea que presione cancel (2) o close (-1)
                break;
        }
    }//GEN-LAST:event_table_productosMouseClicked

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_BuscarCliente;
    private javax.swing.JButton btn_añadirProducto;
    private javax.swing.JButton btn_calcularCambio;
    private javax.swing.JButton btn_registrarVentas;
    private javax.swing.JComboBox<String> comboBox_Cliente;
    private javax.swing.JComboBox<String> comboBox_Producto;
    private javax.swing.JPanel jPanel1;
    public static javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lbl_IVA;
    private javax.swing.JLabel lbl_Subtotal;
    private javax.swing.JLabel lbl_Wallpaper;
    private javax.swing.JLabel lbl_cantidad;
    private javax.swing.JLabel lbl_cliente;
    private javax.swing.JLabel lbl_descuento;
    private javax.swing.JLabel lbl_producto;
    private javax.swing.JLabel lbl_titulo;
    private javax.swing.JLabel lbl_totalPagar;
    private javax.swing.JLabel lbl_totalPagar1;
    private javax.swing.JLabel lbl_totalPagar2;
    private javax.swing.JPanel panel2;
    public static javax.swing.JTable table_productos;
    private javax.swing.JTextField txt_IVA;
    private javax.swing.JTextField txt_cambio;
    private javax.swing.JTextField txt_cantidad;
    private javax.swing.JTextField txt_clienteBuscar;
    private javax.swing.JTextField txt_descuento;
    private javax.swing.JTextField txt_efectivo;
    private javax.swing.JTextField txt_subtotal;
    public static javax.swing.JTextField txt_totalPagar;
    // End of variables declaration//GEN-END:variables

    //Metodo para cargar los clientes en el jComboBox
    private void cargarCliente() {
        Connection cn = conexion.Conexion_BD.conectar();
        String SQL = "SELECT * FROM tb_cliente";
        Statement st;

        try {
            st = cn.createStatement();
            ResultSet rs = st.executeQuery(SQL);
            comboBox_Cliente.removeAllItems();
            comboBox_Cliente.addItem("Seleccione cliente:");
            while (rs.next()) {
                comboBox_Cliente.addItem(rs.getString("nombre") + " " + rs.getString("apellido"));
            }
            cn.close();
        } catch (SQLException e) {
            System.out.println("Error al cargar cliente " + e);
        }
    }

    //Metodo para cargar los productos en el jComboBox
    private void cargarProductos() {
        Connection cn = conexion.Conexion_BD.conectar();
        String sql = "SELECT * FROM tb_producto";
        Statement st;
        try {
            st = (Statement) cn.createStatement();
            ResultSet rs = st.executeQuery(sql);
            comboBox_Producto.removeAllItems();
            comboBox_Producto.addItem("Seleccione producto:");
            while (rs.next()) {
                comboBox_Producto.addItem(rs.getString("nombre"));
            }
            cn.close();
        } catch (SQLException e) {
            System.out.println("¡Error al cargar productos, !" + e);
        }
    }

    //Metodo para validar que el usuario no ingrese caracteres no numericos
    private boolean validar(String valor) {
        try {
            int num = Integer.parseInt(valor);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    //Metodo para validar que el usuario no ingrese caracteres no numericos
    private boolean validarFloat(String valor) {
        try {
            float num = Float.parseFloat(valor);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    //Metodo para mostrar los datos del producto seleccionado
    private void DatosDelProducto() {
        try {
            String sql = "SELECT * FROM tb_producto WHERE nombre = '" + comboBox_Producto.getSelectedItem() + "'";
            Connection cn = conexion.Conexion_BD.conectar();
            Statement st;
            st = (Statement) cn.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                idProducto = rs.getInt("idProducto");
                nombre = rs.getString("nombre");
                cantidadProductoBBDD = rs.getInt("cantidad");
                precioUnitario = rs.getFloat("precio");
                porcentajeIva = rs.getInt("porcentajeIva");
                CalcularIva(precioUnitario, porcentajeIva);//calcula y retorna el iva
            }

        } catch (SQLException e) {
            System.out.println("Error al obtener datos del producto, " + e);
        }
    }

    //Metodo para calcular iva
    private double CalcularIva(float precio, int porcentajeIva) {
        int p_iva = porcentajeIva;

        switch (p_iva) {
            case 0:
                iva = 0.0f;
                break;
            case 14:
                iva = (float) ((precio * cantidad) * 0.14);
                break;
            case 16:
                iva = (float) ((precio * cantidad) * 0.16);
                break;
            default:
                break;
        }

        return iva;
    }

    //Metodo para calcular el total a pagar
    private void CalcularTotalPagar() {
        subtotalGeneral = 0;
        descuentoGeneral = 0;
        ivaGeneral = 0;
        totalPagarGeneral = 0;

        for (DetalleVenta elemento : listaProductos) {
            subtotalGeneral += elemento.getSubTotal();
            descuentoGeneral += elemento.getDescuento();
            ivaGeneral += elemento.getIva();
            totalPagarGeneral += elemento.getTotalPagar();
        }
        //redondear decimales
        subtotalGeneral = Math.round(subtotalGeneral * 100) / 100;
        ivaGeneral = Math.round(ivaGeneral * 100) / 100;
        descuentoGeneral = Math.round(descuentoGeneral * 100) / 100;
        totalPagarGeneral = Math.round(totalPagarGeneral * 100) / 100;

        //enviar datos a la vista
        txt_subtotal.setText(String.valueOf(subtotalGeneral));
        txt_IVA.setText(String.valueOf(ivaGeneral));
        txt_descuento.setText(String.valueOf(descuentoGeneral));
        txt_totalPagar.setText(String.valueOf(totalPagarGeneral));
    }

    // Metodo para obtener id del cliente
    private void ObtenerIdCliente() {
        try {
            String sql = "SELECT * FROM tb_cliente WHERE concat(nombre,' ',apellido) = '" + comboBox_Cliente.getSelectedItem() + "'";
            Connection cn = conexion.Conexion_BD.conectar();
            Statement st;
            st = (Statement) cn.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                idCliente = rs.getInt("idCliente");
            }

        } catch (SQLException e) {
            System.out.println("Error al obtener id del cliente, " + e);
        }
    }

    //Metodo para restar la cantidad (stock) de los productos vendidos
    private void RestarStockProductos(int idProducto, int cantidad) {
        int cantidadProdBaseDeDatos = 0;
        //Obtenemos la cantidad de productos en la BD 
        try {
            Connection cn = conexion.Conexion_BD.conectar();
            String SQL = "SELECT idProducto, cantidad FROM tb_producto WHERE idProducto = '" + idProducto + "'";
            Statement st;
            st = cn.createStatement();
            ResultSet rs = st.executeQuery(SQL);
            while (rs.next()) {
                cantidadProdBaseDeDatos = rs.getInt("cantidad");
            }
            cn.close();
        } catch (SQLException e) {
            System.out.println("Error al consultar el stock, " + e);
        }
        //Actualizamos el stock de la BD restando lo del anterior TRY 
        try {
            Connection cn = conexion.Conexion_BD.conectar();
            PreparedStatement consulta = cn.prepareStatement("UPDATE tb_producto SET cantidad=? WHERE idProducto = '" + idProducto + "'");
            int cantidadNueva = cantidadProdBaseDeDatos - cantidad;
            consulta.setInt(1, cantidadNueva);
            if (consulta.executeUpdate() > 0) {
                //System.out.println("Todo bien");
            }
            cn.close();
        } catch (SQLException e) {
            System.out.println("Error al restar stock, " + e);
        }
    }
}
