package GUI;

import controladores.Ctrl_Cliente;
import java.awt.Color;
import java.awt.Dimension;
import javax.swing.JOptionPane;
import modelo.Cliente;

/**
 *
 * @author Edgar JPC (Yacu)
 */
public class InterCliente extends javax.swing.JInternalFrame {

    int obtenerID_Categoria = 0;

    public InterCliente() {
        initComponents();
        setSize(new Dimension(400, 300));
        setTitle("Nuevo Cliente");
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lbl_titulo = new javax.swing.JLabel();
        lbl_Precio = new javax.swing.JLabel();
        lbl_Cantidad = new javax.swing.JLabel();
        lbl_Descripcion = new javax.swing.JLabel();
        lbl_IVA = new javax.swing.JLabel();
        lbl_nombre5 = new javax.swing.JLabel();
        txt_Nombre = new javax.swing.JTextField();
        txt_Telefono = new javax.swing.JTextField();
        txt_Cedula = new javax.swing.JTextField();
        txt_Apellido = new javax.swing.JTextField();
        txt_Direccion = new javax.swing.JTextField();
        btnGuardar = new javax.swing.JButton();
        lbl_Walpapaer = new javax.swing.JLabel();

        setClosable(true);
        setIconifiable(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lbl_titulo.setFont(new java.awt.Font("Impact", 0, 18)); // NOI18N
        lbl_titulo.setForeground(new java.awt.Color(255, 255, 255));
        lbl_titulo.setText("Nuevo Cliente");
        getContentPane().add(lbl_titulo, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 10, -1, -1));

        lbl_Precio.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 14)); // NOI18N
        lbl_Precio.setForeground(new java.awt.Color(255, 255, 255));
        lbl_Precio.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lbl_Precio.setText("Cedula:");
        getContentPane().add(lbl_Precio, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 110, 80, -1));

        lbl_Cantidad.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 14)); // NOI18N
        lbl_Cantidad.setForeground(new java.awt.Color(255, 255, 255));
        lbl_Cantidad.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lbl_Cantidad.setText("Apellido:");
        getContentPane().add(lbl_Cantidad, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 80, 80, -1));

        lbl_Descripcion.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 14)); // NOI18N
        lbl_Descripcion.setForeground(new java.awt.Color(255, 255, 255));
        lbl_Descripcion.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lbl_Descripcion.setText("Telefono:");
        getContentPane().add(lbl_Descripcion, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 140, 80, -1));

        lbl_IVA.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 14)); // NOI18N
        lbl_IVA.setForeground(new java.awt.Color(255, 255, 255));
        lbl_IVA.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lbl_IVA.setText("Direccion:");
        getContentPane().add(lbl_IVA, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 170, 80, -1));

        lbl_nombre5.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 14)); // NOI18N
        lbl_nombre5.setForeground(new java.awt.Color(255, 255, 255));
        lbl_nombre5.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lbl_nombre5.setText("Nombre:");
        getContentPane().add(lbl_nombre5, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 50, 80, -1));

        txt_Nombre.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 12)); // NOI18N
        getContentPane().add(txt_Nombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 50, 170, -1));

        txt_Telefono.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 12)); // NOI18N
        getContentPane().add(txt_Telefono, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 140, 170, -1));

        txt_Cedula.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 12)); // NOI18N
        getContentPane().add(txt_Cedula, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 110, 170, -1));

        txt_Apellido.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 12)); // NOI18N
        getContentPane().add(txt_Apellido, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 80, 170, -1));

        txt_Direccion.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 12)); // NOI18N
        getContentPane().add(txt_Direccion, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 170, 170, -1));

        btnGuardar.setBackground(new java.awt.Color(0, 204, 204));
        btnGuardar.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 12)); // NOI18N
        btnGuardar.setText("Guardar");
        btnGuardar.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarActionPerformed(evt);
            }
        });
        getContentPane().add(btnGuardar, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 210, 90, 30));

        lbl_Walpapaer.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/fondo3.jpg"))); // NOI18N
        getContentPane().add(lbl_Walpapaer, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 390, 270));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarActionPerformed

        Cliente cliente = new Cliente();
        Ctrl_Cliente controlCliente = new Ctrl_Cliente();

        if (!txt_Nombre.getText().isEmpty() && !txt_Apellido.getText().isEmpty() && !txt_Cedula.getText().isEmpty()) {
            //JOptionPane.showMessageDialog(null, "Correcto");

            if (!controlCliente.existeCliente(txt_Cedula.getText().trim())) {

                cliente.setNombre(txt_Nombre.getText().trim());
                cliente.setApellido(txt_Apellido.getText().trim());
                cliente.setCedula(txt_Cedula.getText().trim());
                cliente.setTelefono(txt_Telefono.getText().trim());
                cliente.setDireccion(txt_Direccion.getText().trim());
                cliente.setEstado(1);

                if (controlCliente.guardar(cliente)) {
                    JOptionPane.showMessageDialog(null, "Registro Guardado");
                    txt_Nombre.setBackground(Color.green);
                    txt_Apellido.setBackground(Color.green);
                    txt_Cedula.setBackground(Color.green);
                    txt_Telefono.setBackground(Color.green);
                    txt_Direccion.setBackground(Color.green);
                } else {
                    JOptionPane.showMessageDialog(null, "Error al Guardar");
                }

            } else {
                JOptionPane.showMessageDialog(null, "El cliente ya esta registrado en la Base de Datos.");
                txt_Nombre.setBackground(Color.white);
                txt_Apellido.setBackground(Color.white);
                txt_Cedula.setBackground(Color.white);
                txt_Telefono.setBackground(Color.white);
                txt_Direccion.setBackground(Color.white);
            }
        } else {
            JOptionPane.showMessageDialog(null, "Completa todos los campos");
            txt_Nombre.setBackground(Color.red);
            txt_Apellido.setBackground(Color.red);
            txt_Cedula.setBackground(Color.red);
            txt_Telefono.setBackground(Color.red);
            txt_Direccion.setBackground(Color.red);
        }

        limpiarCampos();

    }//GEN-LAST:event_btnGuardarActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnGuardar;
    private javax.swing.JLabel lbl_Cantidad;
    private javax.swing.JLabel lbl_Descripcion;
    private javax.swing.JLabel lbl_IVA;
    private javax.swing.JLabel lbl_Precio;
    private javax.swing.JLabel lbl_Walpapaer;
    private javax.swing.JLabel lbl_nombre5;
    private javax.swing.JLabel lbl_titulo;
    private javax.swing.JTextField txt_Apellido;
    private javax.swing.JTextField txt_Cedula;
    private javax.swing.JTextField txt_Direccion;
    private javax.swing.JTextField txt_Nombre;
    private javax.swing.JTextField txt_Telefono;
    // End of variables declaration//GEN-END:variables

    private void limpiarCampos() {
        txt_Apellido.setText("");
        txt_Telefono.setText("");
        txt_Nombre.setText("");
        txt_Cedula.setText("");
        txt_Direccion.setText("");
    }
}
