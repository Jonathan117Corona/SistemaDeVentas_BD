package GUI;

import controladores.Ctrl_Usuario;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.Toolkit;
import javax.swing.JOptionPane;
import modelo.Usuario;

/**
 *
 * @author Edgar JPC (Yacu)
 */
public class FrmUsuario extends javax.swing.JFrame {

    public FrmUsuario() {
        initComponents();
        setSize(new Dimension(400, 330));
        setTitle("Registrar Usuario");
        setLocationRelativeTo(null);
    }

    public Image getIconImage() {
        Image retValue = Toolkit.getDefaultToolkit().getImage(ClassLoader.getSystemResource("img/ventas.png"));
        return retValue;
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lbl_titulo = new javax.swing.JLabel();
        txt_Nombre = new javax.swing.JTextField();
        lbl_Nombre = new javax.swing.JLabel();
        lbl_Apellido = new javax.swing.JLabel();
        txt_Apellido = new javax.swing.JTextField();
        txt_Usuario = new javax.swing.JTextField();
        lbl_Usuario = new javax.swing.JLabel();
        lbl_Contraseña = new javax.swing.JLabel();
        lbl_Telefono = new javax.swing.JLabel();
        txt_Telefono = new javax.swing.JTextField();
        psw_Contraseña = new javax.swing.JPasswordField();
        btn_guardar = new javax.swing.JButton();
        chekB_verClave = new javax.swing.JCheckBox();
        txt_pswVisible = new javax.swing.JTextField();
        btn_cancelar = new javax.swing.JButton();
        lbl_wallpaper = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setIconImage(getIconImage());
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lbl_titulo.setFont(new java.awt.Font("Impact", 0, 24)); // NOI18N
        lbl_titulo.setForeground(new java.awt.Color(255, 255, 255));
        lbl_titulo.setText("Nuevo Usuario");
        getContentPane().add(lbl_titulo, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 20, -1, -1));

        txt_Nombre.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 12)); // NOI18N
        getContentPane().add(txt_Nombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 70, 170, -1));

        lbl_Nombre.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 14)); // NOI18N
        lbl_Nombre.setForeground(new java.awt.Color(255, 255, 255));
        lbl_Nombre.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lbl_Nombre.setText("Nombre:");
        getContentPane().add(lbl_Nombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 70, 80, -1));

        lbl_Apellido.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 14)); // NOI18N
        lbl_Apellido.setForeground(new java.awt.Color(255, 255, 255));
        lbl_Apellido.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lbl_Apellido.setText("Apellido:");
        getContentPane().add(lbl_Apellido, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 100, 80, -1));

        txt_Apellido.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 12)); // NOI18N
        getContentPane().add(txt_Apellido, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 100, 170, -1));

        txt_Usuario.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 12)); // NOI18N
        getContentPane().add(txt_Usuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 130, 170, -1));

        lbl_Usuario.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 14)); // NOI18N
        lbl_Usuario.setForeground(new java.awt.Color(255, 255, 255));
        lbl_Usuario.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lbl_Usuario.setText("Usuario:");
        getContentPane().add(lbl_Usuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 130, 80, -1));

        lbl_Contraseña.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 14)); // NOI18N
        lbl_Contraseña.setForeground(new java.awt.Color(255, 255, 255));
        lbl_Contraseña.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lbl_Contraseña.setText("Contraseña:");
        getContentPane().add(lbl_Contraseña, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 160, 80, -1));

        lbl_Telefono.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 14)); // NOI18N
        lbl_Telefono.setForeground(new java.awt.Color(255, 255, 255));
        lbl_Telefono.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lbl_Telefono.setText("Telefono:");
        getContentPane().add(lbl_Telefono, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 190, 80, -1));

        txt_Telefono.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 12)); // NOI18N
        getContentPane().add(txt_Telefono, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 190, 170, -1));

        psw_Contraseña.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 12)); // NOI18N
        getContentPane().add(psw_Contraseña, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 160, 170, -1));

        btn_guardar.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 14)); // NOI18N
        btn_guardar.setText("Guardar");
        btn_guardar.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_guardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_guardarActionPerformed(evt);
            }
        });
        getContentPane().add(btn_guardar, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 240, 90, 30));

        chekB_verClave.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        chekB_verClave.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                chekB_verClaveMouseClicked(evt);
            }
        });
        chekB_verClave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chekB_verClaveActionPerformed(evt);
            }
        });
        getContentPane().add(chekB_verClave, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 160, 20, 20));

        txt_pswVisible.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 12)); // NOI18N
        getContentPane().add(txt_pswVisible, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 160, 170, -1));

        btn_cancelar.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 14)); // NOI18N
        btn_cancelar.setText("Cancelar");
        btn_cancelar.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_cancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_cancelarActionPerformed(evt);
            }
        });
        getContentPane().add(btn_cancelar, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 240, 90, 30));

        lbl_wallpaper.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/fondo3_1.jpg"))); // NOI18N
        getContentPane().add(lbl_wallpaper, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 400, 350));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn_guardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_guardarActionPerformed

        if (txt_Nombre.getText().isEmpty() || txt_Apellido.getText().isEmpty() || txt_Usuario.getText().isEmpty()
                || psw_Contraseña.getText().isEmpty() || txt_Telefono.getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Complete todos los campos");

        } else {
            //Validamos si el usuario ya esta registrado:
            Usuario usuario = new Usuario();
            Ctrl_Usuario ctrlUsuario = new Ctrl_Usuario();
            if (!ctrlUsuario.existeUsuario(txt_Usuario.getText().trim())) {
                //Enviamos datos del usuario
                usuario.setNombre(txt_Nombre.getText().trim());
                usuario.setApellido(txt_Apellido.getText().trim());
                usuario.setUsuario(txt_Usuario.getText().trim());
                usuario.setPassword(psw_Contraseña.getText().trim());
                usuario.setTelefono(txt_Telefono.getText().trim());
                usuario.setEstado(1);
                if (ctrlUsuario.guardar(usuario)) {
                    JOptionPane.showMessageDialog(null, "Usuario registrado");
                    FrmLogin vL = new FrmLogin();
                    vL.setVisible(true);
                    dispose();
                } else {
                    JOptionPane.showMessageDialog(null, "Error al registrar el usuario");
                }

            } else {
                JOptionPane.showMessageDialog(null, "El usuario ya existe, \npor favro ingrese otro");
            }
        }
        limpiarCampos();
    }//GEN-LAST:event_btn_guardarActionPerformed

    private void chekB_verClaveMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_chekB_verClaveMouseClicked
        // TODO add your handling code here:
        if (chekB_verClave.isSelected() == true) {
            String pass = "";
            char[] passwordIngresado = psw_Contraseña.getPassword();
            for (int i = 0; i < passwordIngresado.length; i++) {
                pass += passwordIngresado[i];
            }
            txt_pswVisible.setText(pass);
            psw_Contraseña.setVisible(false);
            txt_pswVisible.setVisible(true);
        } else {
            String passIngresado = txt_pswVisible.getText().trim();
            psw_Contraseña.setText(passIngresado);
            psw_Contraseña.setVisible(true);
            txt_pswVisible.setVisible(false);
        }
    }//GEN-LAST:event_chekB_verClaveMouseClicked

    private void chekB_verClaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chekB_verClaveActionPerformed

    }//GEN-LAST:event_chekB_verClaveActionPerformed

    private void btn_cancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_cancelarActionPerformed
        // TODO add your handling code here:
        FrmLogin vL = new FrmLogin();
        vL.setVisible(true);
        dispose();
    }//GEN-LAST:event_btn_cancelarActionPerformed

    private void limpiarCampos() {
        txt_Apellido.setText("");
        txt_Telefono.setText("");
        txt_Nombre.setText("");
        txt_Usuario.setText("");
        psw_Contraseña.setText("");
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_cancelar;
    private javax.swing.JButton btn_guardar;
    private javax.swing.JCheckBox chekB_verClave;
    private javax.swing.JLabel lbl_Apellido;
    private javax.swing.JLabel lbl_Contraseña;
    private javax.swing.JLabel lbl_Nombre;
    private javax.swing.JLabel lbl_Telefono;
    private javax.swing.JLabel lbl_Usuario;
    private javax.swing.JLabel lbl_titulo;
    private javax.swing.JLabel lbl_wallpaper;
    private javax.swing.JPasswordField psw_Contraseña;
    private javax.swing.JTextField txt_Apellido;
    private javax.swing.JTextField txt_Nombre;
    private javax.swing.JTextField txt_Telefono;
    private javax.swing.JTextField txt_Usuario;
    private javax.swing.JTextField txt_pswVisible;
    // End of variables declaration//GEN-END:variables
}
