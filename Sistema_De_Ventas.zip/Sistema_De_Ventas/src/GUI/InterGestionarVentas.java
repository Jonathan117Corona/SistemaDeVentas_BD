package GUI;

import controladores.Ctrl_RegistrarVenta;
import java.awt.Dimension;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.*;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import modelo.CabeceraVenta;

/**
 *
 * @author jonat
 */
public class InterGestionarVentas extends javax.swing.JInternalFrame {

    private int idCliente = 0, idVenta;

    public InterGestionarVentas() {
        initComponents();
        setSize(new Dimension(900, 500));
        setTitle("Gestionar Ventas");
        CargarTablaVentas();
        CargarComboClientes();
        //Insertar imagen en el label
        ImageIcon walpaper = new ImageIcon("src/img/fondo3.jpg");
        Icon icono = new ImageIcon(walpaper.getImage().getScaledInstance(900, 500, WIDTH));
        lbl_Walpaper.setIcon(icono);
        repaint();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblAdminCliente = new javax.swing.JLabel();
        pnl1 = new javax.swing.JPanel();
        scrolTabla = new javax.swing.JScrollPane();
        table_ventas = new javax.swing.JTable();
        pnl2 = new javax.swing.JPanel();
        btn_Actualizar = new javax.swing.JButton();
        pnl3 = new javax.swing.JPanel();
        lbl_Nombre = new javax.swing.JLabel();
        txt_totalPagar = new javax.swing.JTextField();
        lbl_Apellido = new javax.swing.JLabel();
        lbl_Cedula = new javax.swing.JLabel();
        lbl_Descripcion = new javax.swing.JLabel();
        txt_fecha = new javax.swing.JTextField();
        comboBox_Cliente = new javax.swing.JComboBox<>();
        comboBox_Estado = new javax.swing.JComboBox<>();
        lbl_Walpaper = new javax.swing.JLabel();

        setClosable(true);
        setIconifiable(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblAdminCliente.setFont(new java.awt.Font("Impact", 0, 18)); // NOI18N
        lblAdminCliente.setForeground(new java.awt.Color(255, 255, 255));
        lblAdminCliente.setText("Administrar Venta");
        getContentPane().add(lblAdminCliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 20, -1, -1));

        pnl1.setBackground(new java.awt.Color(255, 255, 255));
        pnl1.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        pnl1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        table_ventas.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        scrolTabla.setViewportView(table_ventas);

        pnl1.add(scrolTabla, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 730, 270));

        getContentPane().add(pnl1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 50, 730, 270));

        pnl2.setBackground(new java.awt.Color(255, 255, 255));
        pnl2.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        pnl2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btn_Actualizar.setBackground(new java.awt.Color(51, 204, 0));
        btn_Actualizar.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 12)); // NOI18N
        btn_Actualizar.setText("Actualizar");
        btn_Actualizar.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_Actualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_ActualizarActionPerformed(evt);
            }
        });
        pnl2.add(btn_Actualizar, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 90, -1));

        getContentPane().add(pnl2, new org.netbeans.lib.awtextra.AbsoluteConstraints(750, 50, 130, 270));

        pnl3.setBackground(new java.awt.Color(255, 255, 255));
        pnl3.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        pnl3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lbl_Nombre.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 14)); // NOI18N
        lbl_Nombre.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lbl_Nombre.setText("Total Pagar:");
        pnl3.add(lbl_Nombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 80, -1));

        txt_totalPagar.setEditable(false);
        txt_totalPagar.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 12)); // NOI18N
        pnl3.add(txt_totalPagar, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 10, 170, -1));

        lbl_Apellido.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 14)); // NOI18N
        lbl_Apellido.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lbl_Apellido.setText("Fecha:");
        pnl3.add(lbl_Apellido, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 40, 80, -1));

        lbl_Cedula.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 14)); // NOI18N
        lbl_Cedula.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lbl_Cedula.setText("Cliente:");
        pnl3.add(lbl_Cedula, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 10, 80, -1));

        lbl_Descripcion.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 14)); // NOI18N
        lbl_Descripcion.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lbl_Descripcion.setText("Estado:");
        pnl3.add(lbl_Descripcion, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 40, 80, -1));

        txt_fecha.setEditable(false);
        txt_fecha.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 12)); // NOI18N
        pnl3.add(txt_fecha, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 40, 170, -1));

        comboBox_Cliente.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 12)); // NOI18N
        comboBox_Cliente.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccione cliente:", "item 1", "item 2", "item 3", "item 4" }));
        comboBox_Cliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboBox_ClienteActionPerformed(evt);
            }
        });
        pnl3.add(comboBox_Cliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 10, 170, -1));

        comboBox_Estado.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 12)); // NOI18N
        comboBox_Estado.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Activo", "Inactivo" }));
        comboBox_Estado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboBox_EstadoActionPerformed(evt);
            }
        });
        pnl3.add(comboBox_Estado, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 40, 170, -1));

        getContentPane().add(pnl3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 330, 870, 100));

        lbl_Walpaper.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/fondo222.jpg"))); // NOI18N
        getContentPane().add(lbl_Walpaper, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 890, 470));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn_ActualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_ActualizarActionPerformed
        CabeceraVenta cabeceraVenta = new CabeceraVenta();
        Ctrl_RegistrarVenta controlRegistrarVenta = new Ctrl_RegistrarVenta();
        String cliente, estado;
        cliente = comboBox_Cliente.getSelectedItem().toString().trim();
        estado = comboBox_Estado.getSelectedItem().toString().trim();

        //Obtener el id del cliente
        try {
            Connection cn = conexion.Conexion_BD.conectar();
            PreparedStatement pst = cn.prepareStatement(
                    "select idCliente, concat(nombre, ' ', apellido) as cliente "
                    + "from tb_cliente where concat(nombre, ' ', apellido) = '" + cliente + "'");
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                idCliente = rs.getInt("idCliente");
            }
            cn.close();
        } catch (SQLException e) {
            System.out.println("Error en cargar el id cliente: " + e);
        }

        //Actualizar datos
        if (!cliente.equalsIgnoreCase("Seleccione cliente:")) {
            cabeceraVenta.setIdCliente(idCliente);
            if (estado.equalsIgnoreCase("Activo")) {
                cabeceraVenta.setEstado(1);
            } else {
                cabeceraVenta.setEstado(0);
            }

            if (controlRegistrarVenta.actualizar(cabeceraVenta, idVenta)) {
                JOptionPane.showMessageDialog(null, "¡Registro Actualizado!");
                CargarTablaVentas();
                Limpiar();
            } else {
                JOptionPane.showMessageDialog(null, "Error al Actualizar");
            }
        } else {
            JOptionPane.showMessageDialog(null, "Seleccione un registro para actualizar datos");
        }
    }//GEN-LAST:event_btn_ActualizarActionPerformed

    private void comboBox_ClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboBox_ClienteActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_comboBox_ClienteActionPerformed

    private void comboBox_EstadoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboBox_EstadoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_comboBox_EstadoActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_Actualizar;
    private javax.swing.JComboBox<String> comboBox_Cliente;
    private javax.swing.JComboBox<String> comboBox_Estado;
    private javax.swing.JLabel lblAdminCliente;
    private javax.swing.JLabel lbl_Apellido;
    private javax.swing.JLabel lbl_Cedula;
    private javax.swing.JLabel lbl_Descripcion;
    private javax.swing.JLabel lbl_Nombre;
    private javax.swing.JLabel lbl_Walpaper;
    private javax.swing.JPanel pnl1;
    private javax.swing.JPanel pnl2;
    private javax.swing.JPanel pnl3;
    public static javax.swing.JScrollPane scrolTabla;
    public static javax.swing.JTable table_ventas;
    private javax.swing.JTextField txt_fecha;
    private javax.swing.JTextField txt_totalPagar;
    // End of variables declaration//GEN-END:variables

    //Metodo para mostrar todos los clientes registrados
    private void CargarTablaVentas() {
        Connection con = conexion.Conexion_BD.conectar();
        DefaultTableModel model = new DefaultTableModel();
        String sql = "select cv.idCabeceraVenta as id, concat(c.nombre, ' ', c.apellido) as cliente, cv.valorPagar as total,"
                + " cv.fechaVenta as fecha, cv.estado from tb_cabecera_venta as cv, tb_cliente as c where cv.idCliente = c.idCliente;";
        Statement st;
        try {
            st = con.createStatement();
            ResultSet rs = st.executeQuery(sql);
            InterGestionarVentas.table_ventas = new JTable(model);
            InterGestionarVentas.scrolTabla.setViewportView(InterGestionarVentas.table_ventas);

            model.addColumn("N°");//ID
            model.addColumn("Cliente");
            model.addColumn("Total Pagar");
            model.addColumn("Fecha Venta");
            model.addColumn("estado");

            while (rs.next()) {
                Object fila[] = new Object[5];
                for (int i = 0; i < 5; i++) {
                    if (i == 4) {
                        String estado = String.valueOf(rs.getObject(i + 1));
                        if (estado.equalsIgnoreCase("1")) {
                            fila[i] = "Activo";
                        } else {
                            fila[i] = "Inactivo";
                        }
                    } else {
                        fila[i] = rs.getObject(i + 1);
                    }
                }
                model.addRow(fila);
            }
            con.close();
        } catch (SQLException e) {
            System.out.println("Error al llenar la tabla de ventas: " + e);
        }
        //evento para obtener campo al cual el usuario da click
        //y obtener la interfaz que mostrara la informacion general
        table_ventas.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int fila_point = table_ventas.rowAtPoint(e.getPoint());
                int columna_point = 0;

                if (fila_point > -1) {
                    idVenta = (int) model.getValueAt(fila_point, columna_point);
                    EnviarDatosVentaSeleccionada(idVenta);//metodo
                }
            }
        });
    }

    //Metodo para cargar los clientes en el comboBox
    private void CargarComboClientes() {
        Connection cn = conexion.Conexion_BD.conectar();
        String sql = "SELECT * FROM tb_cliente";
        Statement st;
        try {
            st = cn.createStatement();
            ResultSet rs = st.executeQuery(sql);
            comboBox_Cliente.removeAllItems();
            comboBox_Cliente.addItem("Seleccione cliente:");
            while (rs.next()) {
                comboBox_Cliente.addItem(rs.getString("nombre") + " " + rs.getString("apellido"));
            }
            cn.close();
        } catch (SQLException e) {
            System.out.println("¡Error al cargar clientes, !" + e);
        }
    }

    //Metodo que envia datos seleccionados
    private void EnviarDatosVentaSeleccionada(int idVenta) {
        try {
            Connection con = conexion.Conexion_BD.conectar();
            PreparedStatement pst = con.prepareStatement(
                    "SELECT cv.idCabeceraVenta, cv.idCliente, concat(c.nombre, ' ', c.apellido) AS cliente, "
                    + "cv.valorPagar, cv.fechaVenta, cv.estado  FROM tb_cabecera_venta AS cv, "
                    + "tb_cliente AS c WHERE  cv.idCabeceraVenta = '" + idVenta + "' AND cv.idCliente = c.idCliente;");
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                comboBox_Cliente.setSelectedItem(rs.getString("cliente"));
                txt_totalPagar.setText(rs.getString("valorPagar"));
                txt_fecha.setText(rs.getString("fechaVenta"));
                int estado = rs.getInt("estado");
                if (estado == 1) {
                    comboBox_Estado.setSelectedItem("Activo");
                } else {
                    comboBox_Estado.setSelectedItem("Inactivo");
                }
            }
            con.close();
        } catch (SQLException e) {
            System.out.println("Error al seleccionar venta: " + e);
        }
    }

    //Metodo para cargar las categorias JcomboBox
    private void Limpiar() {
        txt_totalPagar.setText("");
        txt_fecha.setText("");
        comboBox_Cliente.setSelectedItem("Seleccione cliente:");
        comboBox_Estado.setSelectedItem("Activo");
        idCliente = 0;
    }
}
