package GUI;

import controladores.Ctrl_Usuario;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.Toolkit;
import javax.swing.JOptionPane;
import modelo.Usuario;

/**
 *
 * @author jonat
 */
public class FrmLogin extends javax.swing.JFrame {

    public FrmLogin() {
        initComponents();
        setResizable(false);
        setLocationRelativeTo(null);
        setTitle("Login");
        setSize(new Dimension(700,500));       
    }

    public Image getIconImage(){
        Image retValue = Toolkit.getDefaultToolkit().getImage(ClassLoader.getSystemResource("img/ventas.png"));
        return retValue;
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Panel_1 = new javax.swing.JPanel();
        lbl_WoowGames = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        lbl_Sistem = new javax.swing.JLabel();
        lbl_logoCarrito = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        Panel_2 = new javax.swing.JPanel();
        lbl_logoUsuario1 = new javax.swing.JLabel();
        lbl_LogoUsuario = new javax.swing.JLabel();
        lbl_LogoPasw = new javax.swing.JLabel();
        txt_Usuario = new javax.swing.JTextField();
        psw_Contraseña = new javax.swing.JPasswordField();
        btn_IniciarSesion = new javax.swing.JButton();
        btn_registrarUsuario = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setIconImage(getIconImage());
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Panel_1.setBackground(new java.awt.Color(0, 204, 204));
        Panel_1.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        Panel_1.setForeground(new java.awt.Color(255, 255, 255));

        lbl_WoowGames.setFont(new java.awt.Font("Impact", 0, 48)); // NOI18N
        lbl_WoowGames.setText("Woow Games");

        jLabel2.setText("jLabel2");

        lbl_Sistem.setFont(new java.awt.Font("Impact", 0, 24)); // NOI18N
        lbl_Sistem.setText("Sistema de Ventas");

        lbl_logoCarrito.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/carrito1.png"))); // NOI18N

        jLabel1.setText("Corona Medina Jonathan Jair");

        jLabel3.setText("Portillo Castañeda Edgar Jesus");

        jLabel4.setText("Lopez Medina Luis Arturo");

        javax.swing.GroupLayout Panel_1Layout = new javax.swing.GroupLayout(Panel_1);
        Panel_1.setLayout(Panel_1Layout);
        Panel_1Layout.setHorizontalGroup(
            Panel_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Panel_1Layout.createSequentialGroup()
                .addGroup(Panel_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Panel_1Layout.createSequentialGroup()
                        .addGap(82, 82, 82)
                        .addGroup(Panel_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(Panel_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel3)
                                .addComponent(jLabel1)
                                .addComponent(jLabel4))
                            .addComponent(lbl_Sistem))
                        .addGap(114, 114, 114)
                        .addComponent(jLabel2))
                    .addGroup(Panel_1Layout.createSequentialGroup()
                        .addGap(48, 48, 48)
                        .addComponent(lbl_WoowGames))
                    .addGroup(Panel_1Layout.createSequentialGroup()
                        .addGap(99, 99, 99)
                        .addComponent(lbl_logoCarrito)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        Panel_1Layout.setVerticalGroup(
            Panel_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Panel_1Layout.createSequentialGroup()
                .addGap(72, 72, 72)
                .addComponent(lbl_WoowGames)
                .addGap(56, 56, 56)
                .addComponent(lbl_logoCarrito)
                .addGroup(Panel_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Panel_1Layout.createSequentialGroup()
                        .addGap(48, 48, 48)
                        .addComponent(jLabel2))
                    .addGroup(Panel_1Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel4)))
                .addGap(18, 18, 18)
                .addComponent(lbl_Sistem)
                .addContainerGap(56, Short.MAX_VALUE))
        );

        getContentPane().add(Panel_1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 350, 500));

        Panel_2.setBackground(new java.awt.Color(204, 204, 204));
        Panel_2.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        Panel_2.setForeground(new java.awt.Color(255, 255, 255));

        lbl_logoUsuario1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/user1.png"))); // NOI18N

        lbl_LogoUsuario.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/user2.png"))); // NOI18N

        lbl_LogoPasw.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/password.png"))); // NOI18N

        txt_Usuario.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 18)); // NOI18N
        txt_Usuario.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txt_UsuarioKeyPressed(evt);
            }
        });

        psw_Contraseña.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 18)); // NOI18N
        psw_Contraseña.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                psw_ContraseñaKeyPressed(evt);
            }
        });

        btn_IniciarSesion.setFont(new java.awt.Font("Impact", 0, 18)); // NOI18N
        btn_IniciarSesion.setText("Iniciar Sesion");
        btn_IniciarSesion.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_IniciarSesion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_IniciarSesionActionPerformed(evt);
            }
        });

        btn_registrarUsuario.setFont(new java.awt.Font("Impact", 0, 18)); // NOI18N
        btn_registrarUsuario.setText("Registrarse");
        btn_registrarUsuario.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_registrarUsuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_registrarUsuarioActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout Panel_2Layout = new javax.swing.GroupLayout(Panel_2);
        Panel_2.setLayout(Panel_2Layout);
        Panel_2Layout.setHorizontalGroup(
            Panel_2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Panel_2Layout.createSequentialGroup()
                .addGap(48, 48, 48)
                .addGroup(Panel_2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(lbl_LogoPasw, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lbl_LogoUsuario, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(Panel_2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txt_Usuario)
                    .addComponent(psw_Contraseña, javax.swing.GroupLayout.DEFAULT_SIZE, 170, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Panel_2Layout.createSequentialGroup()
                .addContainerGap(112, Short.MAX_VALUE)
                .addGroup(Panel_2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Panel_2Layout.createSequentialGroup()
                        .addComponent(lbl_logoUsuario1)
                        .addGap(106, 106, 106))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Panel_2Layout.createSequentialGroup()
                        .addGroup(Panel_2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(btn_IniciarSesion, javax.swing.GroupLayout.DEFAULT_SIZE, 120, Short.MAX_VALUE)
                            .addComponent(btn_registrarUsuario, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(103, 103, 103))))
        );
        Panel_2Layout.setVerticalGroup(
            Panel_2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Panel_2Layout.createSequentialGroup()
                .addGap(64, 64, 64)
                .addComponent(lbl_logoUsuario1)
                .addGap(51, 51, 51)
                .addGroup(Panel_2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(lbl_LogoUsuario)
                    .addComponent(txt_Usuario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(Panel_2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(lbl_LogoPasw)
                    .addComponent(psw_Contraseña, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(36, 36, 36)
                .addComponent(btn_IniciarSesion, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btn_registrarUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(47, Short.MAX_VALUE))
        );

        getContentPane().add(Panel_2, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 0, 350, 500));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn_IniciarSesionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_IniciarSesionActionPerformed
        Login();
        limpiarCampos();
    }//GEN-LAST:event_btn_IniciarSesionActionPerformed

    private void txt_UsuarioKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_UsuarioKeyPressed
        if(evt.getKeyCode()==evt.VK_ENTER){
            psw_Contraseña.requestFocus();
        }
    }//GEN-LAST:event_txt_UsuarioKeyPressed

    private void psw_ContraseñaKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_psw_ContraseñaKeyPressed
        if(evt.getKeyCode()==evt.VK_ENTER){
            Login();
        }
    }//GEN-LAST:event_psw_ContraseñaKeyPressed

    private void btn_registrarUsuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_registrarUsuarioActionPerformed
        // TODO add your handling code here:
        FrmUsuario vU = new FrmUsuario();
        vU.setVisible(true);
        dispose();
    }//GEN-LAST:event_btn_registrarUsuarioActionPerformed

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FrmLogin().setVisible(true);
            }
        });
    }
    
    private void Login(){
        if(!txt_Usuario.getText().isEmpty() && !psw_Contraseña.getText().isEmpty()){
            Ctrl_Usuario controlUsuario = new Ctrl_Usuario();
            Usuario usuario = new Usuario();
            usuario.setUsuario(txt_Usuario.getText().trim());
            usuario.setPassword(psw_Contraseña.getText().trim());
            
            if(controlUsuario.loginUser(usuario)){
                //JOptionPane.showMessageDialog(null, "Inicio de Sesion correcto.........");
                FrmMenu vM = new FrmMenu();
                vM.setVisible(true);
                dispose();
            }else{
                JOptionPane.showMessageDialog(null, "Usuario y/o contraseña incorectos");
            }
            
        }else{
            JOptionPane.showMessageDialog(null, "Ingrese los campos requeridos");
        }
    }
    
    public void limpiarCampos(){
        txt_Usuario.setText("");
        psw_Contraseña.setText("");
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel Panel_1;
    private javax.swing.JPanel Panel_2;
    private javax.swing.JButton btn_IniciarSesion;
    private javax.swing.JButton btn_registrarUsuario;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel lbl_LogoPasw;
    private javax.swing.JLabel lbl_LogoUsuario;
    private javax.swing.JLabel lbl_Sistem;
    private javax.swing.JLabel lbl_WoowGames;
    private javax.swing.JLabel lbl_logoCarrito;
    private javax.swing.JLabel lbl_logoUsuario1;
    private javax.swing.JPasswordField psw_Contraseña;
    private javax.swing.JTextField txt_Usuario;
    // End of variables declaration//GEN-END:variables
}
