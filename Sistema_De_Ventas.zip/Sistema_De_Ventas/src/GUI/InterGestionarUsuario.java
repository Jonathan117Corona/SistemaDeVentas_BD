package GUI;

import controladores.Ctrl_Usuario;
import java.awt.Dimension;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.*;
//import javax.swing.Icon;
//import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import modelo.Usuario;

/**
 *
 * @author Edgar JPC (Yacu)
 */
public class InterGestionarUsuario extends javax.swing.JInternalFrame {

    private int idUsuario;

    public InterGestionarUsuario() {
        initComponents();
        setSize(new Dimension(900, 500));
        setTitle("Gestionar Usuarios");
        CargarTablaUsuarios();
        //Insertar imagen en el label
//        ImageIcon walpaper = new ImageIcon("src/img/fondo3.jpg");
//        Icon icono = new ImageIcon(walpaper.getImage().getScaledInstance(900, 500, WIDTH));
//        lbl_Walpaper.setIcon(icono);
//        repaint();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblAdminUsuario = new javax.swing.JLabel();
        pnl1 = new javax.swing.JPanel();
        scrolTabla = new javax.swing.JScrollPane();
        table_usuarios = new javax.swing.JTable();
        pnl2 = new javax.swing.JPanel();
        btn_Actualizar = new javax.swing.JButton();
        btn_Eliminar = new javax.swing.JButton();
        pnl3 = new javax.swing.JPanel();
        lbl_Nombre = new javax.swing.JLabel();
        txt_nombre = new javax.swing.JTextField();
        lbl_Contraseña = new javax.swing.JLabel();
        lbl_Apellido = new javax.swing.JLabel();
        lbl_telefono = new javax.swing.JLabel();
        lbl_usuario = new javax.swing.JLabel();
        txt_contra = new javax.swing.JTextField();
        txt_usuario = new javax.swing.JTextField();
        txt_telefono = new javax.swing.JTextField();
        txt_apellido = new javax.swing.JTextField();
        lbl_Walpaper = new javax.swing.JLabel();

        setClosable(true);
        setIconifiable(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblAdminUsuario.setFont(new java.awt.Font("Impact", 0, 18)); // NOI18N
        lblAdminUsuario.setForeground(new java.awt.Color(255, 255, 255));
        lblAdminUsuario.setText("Administrar Usuario");
        getContentPane().add(lblAdminUsuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 20, -1, -1));

        pnl1.setBackground(new java.awt.Color(255, 255, 255));
        pnl1.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        pnl1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        table_usuarios.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        scrolTabla.setViewportView(table_usuarios);

        pnl1.add(scrolTabla, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 730, 270));

        getContentPane().add(pnl1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 50, 730, 270));

        pnl2.setBackground(new java.awt.Color(255, 255, 255));
        pnl2.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        pnl2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btn_Actualizar.setBackground(new java.awt.Color(51, 204, 0));
        btn_Actualizar.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 12)); // NOI18N
        btn_Actualizar.setText("Actualizar");
        btn_Actualizar.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_Actualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_ActualizarActionPerformed(evt);
            }
        });
        pnl2.add(btn_Actualizar, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 90, -1));

        btn_Eliminar.setBackground(new java.awt.Color(255, 51, 51));
        btn_Eliminar.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 12)); // NOI18N
        btn_Eliminar.setText("Eliminar");
        btn_Eliminar.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_Eliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_EliminarActionPerformed(evt);
            }
        });
        pnl2.add(btn_Eliminar, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 50, 90, -1));

        getContentPane().add(pnl2, new org.netbeans.lib.awtextra.AbsoluteConstraints(750, 50, 130, 270));

        pnl3.setBackground(new java.awt.Color(255, 255, 255));
        pnl3.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        pnl3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lbl_Nombre.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 14)); // NOI18N
        lbl_Nombre.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lbl_Nombre.setText("Nombre:");
        pnl3.add(lbl_Nombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 80, -1));

        txt_nombre.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 12)); // NOI18N
        pnl3.add(txt_nombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 10, 170, -1));

        lbl_Contraseña.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 14)); // NOI18N
        lbl_Contraseña.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lbl_Contraseña.setText("Contraseña:");
        pnl3.add(lbl_Contraseña, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 40, 80, -1));

        lbl_Apellido.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 14)); // NOI18N
        lbl_Apellido.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lbl_Apellido.setText("Apellido:");
        pnl3.add(lbl_Apellido, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 10, 80, -1));

        lbl_telefono.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 14)); // NOI18N
        lbl_telefono.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lbl_telefono.setText("Telefono:");
        pnl3.add(lbl_telefono, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 40, 80, -1));

        lbl_usuario.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 14)); // NOI18N
        lbl_usuario.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lbl_usuario.setText("Usuario:");
        pnl3.add(lbl_usuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 10, 80, -1));

        txt_contra.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 12)); // NOI18N
        pnl3.add(txt_contra, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 40, 170, -1));

        txt_usuario.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 12)); // NOI18N
        pnl3.add(txt_usuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 10, 170, -1));

        txt_telefono.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 12)); // NOI18N
        pnl3.add(txt_telefono, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 40, 170, -1));

        txt_apellido.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 12)); // NOI18N
        pnl3.add(txt_apellido, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 10, 170, -1));

        getContentPane().add(pnl3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 330, 870, 100));

        lbl_Walpaper.setBackground(new java.awt.Color(0, 0, 0));
        lbl_Walpaper.setForeground(new java.awt.Color(0, 0, 0));
        lbl_Walpaper.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/fondo222.jpg"))); // NOI18N
        getContentPane().add(lbl_Walpaper, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 890, 470));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn_ActualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_ActualizarActionPerformed
        
        Usuario usuario = new Usuario();
        Ctrl_Usuario ctrlUsuario = new Ctrl_Usuario(); 
            
        if (idUsuario == 0) {
            JOptionPane.showMessageDialog(null, "¡Seleccione un Usuario!");
        } else {
            if (txt_nombre.getText().isEmpty() || txt_apellido.getText().isEmpty() || txt_usuario.getText().isEmpty()
                    || txt_contra.getText().isEmpty() || txt_telefono.getText().isEmpty()) {
                JOptionPane.showMessageDialog(null, "¡Completa todos los campos!");

            } else {
                usuario.setNombre(txt_nombre.getText().trim());
                usuario.setApellido(txt_apellido.getText().trim());
                usuario.setUsuario(txt_usuario.getText().trim());
                usuario.setPassword(txt_contra.getText().trim());
                usuario.setTelefono(txt_telefono.getText().trim());
                usuario.setEstado(1);
                
                if(ctrlUsuario.actualizar(usuario, idUsuario)){
                    JOptionPane.showMessageDialog(null, "¡Actualizacion Exitosa!");
                    Limpiar();
                    CargarTablaUsuarios();
                    idUsuario = 0;
                }else{
                    JOptionPane.showMessageDialog(null, "¡Error al Actualizar usuario!");
                    Limpiar();
                }
            }
        }
    }//GEN-LAST:event_btn_ActualizarActionPerformed

    private void btn_EliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_EliminarActionPerformed

         Ctrl_Usuario controlUsuario = new Ctrl_Usuario();
        if (idUsuario == 0) {
            JOptionPane.showMessageDialog(null, "¡Seleccione un usuario!");
        } else {
            if (!controlUsuario.eliminar(idUsuario)) {
                JOptionPane.showMessageDialog(null, "¡Usuario Eliminado!");
                CargarTablaUsuarios();
                Limpiar();
                idUsuario = 0;
            } else {
                JOptionPane.showMessageDialog(null, "¡Error al eliminar usuario!");
                Limpiar();
            }
        }
    }//GEN-LAST:event_btn_EliminarActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_Actualizar;
    private javax.swing.JButton btn_Eliminar;
    private javax.swing.JLabel lblAdminUsuario;
    private javax.swing.JLabel lbl_Apellido;
    private javax.swing.JLabel lbl_Contraseña;
    private javax.swing.JLabel lbl_Nombre;
    private javax.swing.JLabel lbl_Walpaper;
    private javax.swing.JLabel lbl_telefono;
    private javax.swing.JLabel lbl_usuario;
    private javax.swing.JPanel pnl1;
    private javax.swing.JPanel pnl2;
    private javax.swing.JPanel pnl3;
    public static javax.swing.JScrollPane scrolTabla;
    public static javax.swing.JTable table_usuarios;
    private javax.swing.JTextField txt_apellido;
    private javax.swing.JTextField txt_contra;
    private javax.swing.JTextField txt_nombre;
    private javax.swing.JTextField txt_telefono;
    private javax.swing.JTextField txt_usuario;
    // End of variables declaration//GEN-END:variables

    
    //Metodo para mostrar todos los clientes registrados
    private void CargarTablaUsuarios() {
        Connection con = conexion.Conexion_BD.conectar();
        DefaultTableModel model = new DefaultTableModel();
        String sql = "SELECT * FROM tb_usuario";
        Statement st;
        try {
            st = con.createStatement();
            ResultSet rs = st.executeQuery(sql);
            InterGestionarUsuario.table_usuarios = new JTable(model);
            InterGestionarUsuario.scrolTabla.setViewportView(InterGestionarUsuario.table_usuarios);

            model.addColumn("N°");//ID
            model.addColumn("nombre");
            model.addColumn("apellido");
            model.addColumn("usuario");
            model.addColumn("contraseña");
            model.addColumn("telefono");
            model.addColumn("estado");

            while (rs.next()) {
                Object fila[] = new Object[7];
                for (int i = 0; i < 7; i++) {
                    fila[i] = rs.getObject(i + 1);
                }
                model.addRow(fila);
            }
            con.close();
        } catch (SQLException e) {
            System.out.println("Error al llenar la tabla usuarios: " + e);
        }
        //evento para obtener campo al cual el usuario da click
        //y obtener la interfaz que mostrara la informacion general
        table_usuarios.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int fila_point = table_usuarios.rowAtPoint(e.getPoint());
                int columna_point = 0;

                if (fila_point > -1) {
                    idUsuario = (int) model.getValueAt(fila_point, columna_point);
                    EnviarDatosUsuario(idUsuario);//metodo
                }
            }
        });
    }

    //Metodo que envia datos seleccionados
    private void EnviarDatosUsuario(int idUsuario) {
        try {
            Connection con = conexion.Conexion_BD.conectar();
            PreparedStatement pst = con.prepareStatement(
                    "SELECT * FROM tb_usuario WHERE idUsuario = '" + idUsuario + "'");
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                txt_nombre.setText(rs.getString("nombre"));
                txt_apellido.setText(rs.getString("apellido"));
                txt_usuario.setText(rs.getString("usuario"));
                txt_contra.setText(rs.getString("password"));
                txt_telefono.setText(rs.getString("telefono"));
            }
            con.close();
        } catch (SQLException e) {
            System.out.println("Error al seleccionar el usuario: " + e);
        }
    }

    //Metodo para cargar las categorias JcomboBox
    private void Limpiar() {
        txt_nombre.setText("");
        txt_contra.setText("");
        txt_usuario.setText("");
        txt_telefono.setText("");
        txt_apellido.setText("");
    }
}
