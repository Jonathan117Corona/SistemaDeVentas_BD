package GUI;

import controladores.Ctrl_Producto;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.HeadlessException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import modelo.Producto;

/**
 *
 * @author Artur
 */
public class InterProducto extends javax.swing.JInternalFrame {

    int obtenerID_Categoria = 0;

    public InterProducto() {
        initComponents();
        setSize(new Dimension(400, 300));
        setTitle("Nuevo producto");
        cargarComboCategoria();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lbl_titulo = new javax.swing.JLabel();
        lbl_Precio = new javax.swing.JLabel();
        lbl_Cantidad = new javax.swing.JLabel();
        lbl_Descripcion = new javax.swing.JLabel();
        lbl_IVA = new javax.swing.JLabel();
        lbl_nombre = new javax.swing.JLabel();
        lbl_nombre5 = new javax.swing.JLabel();
        txt_Nombre = new javax.swing.JTextField();
        txt_Descripcion = new javax.swing.JTextField();
        txt_Precio = new javax.swing.JTextField();
        txt_Cantidad = new javax.swing.JTextField();
        comboBox_IVA = new javax.swing.JComboBox<>();
        ComboBox_Categoria = new javax.swing.JComboBox<>();
        btnGuardar = new javax.swing.JButton();
        lbl_Walpapaer = new javax.swing.JLabel();

        setClosable(true);
        setIconifiable(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lbl_titulo.setFont(new java.awt.Font("Impact", 0, 18)); // NOI18N
        lbl_titulo.setForeground(new java.awt.Color(255, 255, 255));
        lbl_titulo.setText("Nuevo producto");
        getContentPane().add(lbl_titulo, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 10, -1, -1));

        lbl_Precio.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 14)); // NOI18N
        lbl_Precio.setForeground(new java.awt.Color(255, 255, 255));
        lbl_Precio.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lbl_Precio.setText("Precio:");
        getContentPane().add(lbl_Precio, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 110, 80, -1));

        lbl_Cantidad.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 14)); // NOI18N
        lbl_Cantidad.setForeground(new java.awt.Color(255, 255, 255));
        lbl_Cantidad.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lbl_Cantidad.setText("Cantidad:");
        getContentPane().add(lbl_Cantidad, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 80, 80, -1));

        lbl_Descripcion.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 14)); // NOI18N
        lbl_Descripcion.setForeground(new java.awt.Color(255, 255, 255));
        lbl_Descripcion.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lbl_Descripcion.setText("Descripcion:");
        getContentPane().add(lbl_Descripcion, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 140, 80, -1));

        lbl_IVA.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 14)); // NOI18N
        lbl_IVA.setForeground(new java.awt.Color(255, 255, 255));
        lbl_IVA.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lbl_IVA.setText("IVA:");
        getContentPane().add(lbl_IVA, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 170, 80, -1));

        lbl_nombre.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 14)); // NOI18N
        lbl_nombre.setForeground(new java.awt.Color(255, 255, 255));
        lbl_nombre.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lbl_nombre.setText("Categoria:");
        getContentPane().add(lbl_nombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 200, 80, -1));

        lbl_nombre5.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 14)); // NOI18N
        lbl_nombre5.setForeground(new java.awt.Color(255, 255, 255));
        lbl_nombre5.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lbl_nombre5.setText("Nombre:");
        getContentPane().add(lbl_nombre5, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 50, 80, -1));

        txt_Nombre.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 12)); // NOI18N
        getContentPane().add(txt_Nombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 50, 170, -1));

        txt_Descripcion.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 12)); // NOI18N
        getContentPane().add(txt_Descripcion, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 140, 170, -1));

        txt_Precio.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 12)); // NOI18N
        getContentPane().add(txt_Precio, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 110, 170, -1));

        txt_Cantidad.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 12)); // NOI18N
        getContentPane().add(txt_Cantidad, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 80, 170, -1));

        comboBox_IVA.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 12)); // NOI18N
        comboBox_IVA.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccione IVA:", "No grava IVA", "12%", "14%" }));
        getContentPane().add(comboBox_IVA, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 170, 170, -1));

        ComboBox_Categoria.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 12)); // NOI18N
        ComboBox_Categoria.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccione categoria:", " ", " " }));
        getContentPane().add(ComboBox_Categoria, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 200, 170, -1));

        btnGuardar.setBackground(new java.awt.Color(0, 204, 204));
        btnGuardar.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 12)); // NOI18N
        btnGuardar.setText("Guardar");
        btnGuardar.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarActionPerformed(evt);
            }
        });
        getContentPane().add(btnGuardar, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 230, 90, 25));

        lbl_Walpapaer.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/fondo3.jpg"))); // NOI18N
        getContentPane().add(lbl_Walpapaer, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 390, 270));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarActionPerformed

        Producto producto = new Producto();
        Ctrl_Producto controlProducto = new Ctrl_Producto();
        String iva = "", categoria = "";
        iva = comboBox_IVA.getSelectedItem().toString().trim();
        categoria = ComboBox_Categoria.getSelectedItem().toString().trim();

        //Validamos los campos
        if (txt_Nombre.getText().equals("") || txt_Cantidad.getText().equals("") || txt_Precio.getText().equals("")) {
            JOptionPane.showMessageDialog(null, "Complete todos los campos");
            txt_Nombre.setBackground(Color.red);
            txt_Cantidad.setBackground(Color.red);
            txt_Precio.setBackground(Color.red);
        } else {
            //Consulta para ver si el producto ya esta registrado
            if (!controlProducto.existeProdcuto(txt_Nombre.getText().trim())) {
                if (iva.equalsIgnoreCase("Seleccione IVA:")) {
                    JOptionPane.showMessageDialog(null, "Seleccione IVA");
                } else {
                    if (categoria.equalsIgnoreCase("Seleccione categoria:")) {
                        JOptionPane.showMessageDialog(null, "Seleccione categoria");
                    } else {

                        try {
                            producto.setNombre(txt_Nombre.getText().trim());
                            producto.setCantidad(Integer.parseInt(txt_Cantidad.getText().trim()));
                            String precioTXT = "";
                            float PRECIO = 0.0f;
                            precioTXT = txt_Precio.getText().trim();
                            boolean aux = false;

                            //Si el usuario ingresa (,) como (.) decimal lo transformamos a punto
                            for (int i = 0; i < precioTXT.length(); i++) {
                                if (precioTXT.charAt(i) == ',') {
                                    String precioNuevo = precioTXT.replace(",", ".");
                                    PRECIO = Float.parseFloat(precioNuevo);
                                    aux = true;
                                }
                            }

                            //Evaluamos la condicion
                            if (aux == true) {
                                producto.setPrecio(PRECIO);
                            } else {
                                PRECIO = Float.parseFloat(precioTXT);
                                producto.setPrecio(PRECIO);
                            }

                            producto.setDescripcion(txt_Descripcion.getText().trim());

                            //Porcentaje IVA
                            if (iva.equalsIgnoreCase("No grava IVA")) {
                                producto.setPorcentajeIVA(0);
                            } else if (iva.equalsIgnoreCase("12%")) {
                                producto.setPorcentajeIVA(12);
                            } else if (iva.equalsIgnoreCase("14%")) {
                                producto.setPorcentajeIVA(14);
                            }

                            //ID de la categoria, cargamos un metodo
                            idCATEGORIA();
                            producto.setIdCategoria(obtenerID_Categoria);
                            producto.setEstado(1);

                            if (controlProducto.guardar(producto)) {
                                JOptionPane.showMessageDialog(null, "Registro guardado");
                                txt_Nombre.setBackground(Color.green);
                                txt_Cantidad.setBackground(Color.green);
                                txt_Precio.setBackground(Color.green);
                                txt_Descripcion.setBackground(Color.green);
                                //cargarComboCategoria(); 
                                comboBox_IVA.setSelectedItem("Seleccione IVA:");
                                ComboBox_Categoria.setSelectedItem("Seleccione categoria:");
                                limpiarCampos();
                            } else {
                                JOptionPane.showMessageDialog(null, "Error al guardar ");
                            }

                        } catch (HeadlessException | NumberFormatException e) {
                            System.out.println("Error en: " + e);
                        }
                    }
                }

            } else {
                JOptionPane.showMessageDialog(null, "El producto ya existe en la base de datos");
            }

        }
    }//GEN-LAST:event_btnGuardarActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> ComboBox_Categoria;
    private javax.swing.JButton btnGuardar;
    private javax.swing.JComboBox<String> comboBox_IVA;
    private javax.swing.JLabel lbl_Cantidad;
    private javax.swing.JLabel lbl_Descripcion;
    private javax.swing.JLabel lbl_IVA;
    private javax.swing.JLabel lbl_Precio;
    private javax.swing.JLabel lbl_Walpapaer;
    private javax.swing.JLabel lbl_nombre;
    private javax.swing.JLabel lbl_nombre5;
    private javax.swing.JLabel lbl_titulo;
    private javax.swing.JTextField txt_Cantidad;
    private javax.swing.JTextField txt_Descripcion;
    private javax.swing.JTextField txt_Nombre;
    private javax.swing.JTextField txt_Precio;
    // End of variables declaration//GEN-END:variables

   
    //Metodo para cargar las categorias
    private void cargarComboCategoria() {
        Connection cn = conexion.Conexion_BD.conectar();
        String SQL = "SELECT * FROM tb_categoria";
        Statement st;
        
        try {
            st = cn.createStatement();
            ResultSet rs = st.executeQuery(SQL);
            ComboBox_Categoria.removeAllItems();
            ComboBox_Categoria.addItem("Seleccione categoria: ");
            while (rs.next()) {
                ComboBox_Categoria.addItem(rs.getString("descripcion"));
            }
            cn.close();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al cargar categorias");
        }

    }

    //Metodo para obtener el id de la categoria
    private int idCATEGORIA() {
        String SQL = "SELECT * FROM tb_categoria WHERE descripcion ='" + ComboBox_Categoria.getSelectedItem() + "'";
        Statement st;

        try {
            Connection cn = conexion.Conexion_BD.conectar();
            st = cn.createStatement();
            ResultSet rs = st.executeQuery(SQL);
            while (rs.next()) {
                obtenerID_Categoria = rs.getInt("idCategoria");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al obtener la categoria");
        }

        return obtenerID_Categoria;
    }

    private void limpiarCampos() {
        txt_Cantidad.setText("");
        txt_Descripcion.setText("");
        txt_Nombre.setText("");
        txt_Precio.setText("");
    }
}
