package GUI;

import controladores.Ctrl_Producto;
import java.awt.Dimension;
import javax.swing.JOptionPane;
import modelo.Producto;
import java.sql.*;

/**
 *
 * @author Artur
 */
public class InterActualizarStock extends javax.swing.JInternalFrame {

    int idProducto = 0, cantidad = 0;
    
    public InterActualizarStock() {
        initComponents();
        setTitle("Actualizar Stock");
        setSize(new Dimension(400, 270));
        CargarProductos();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lbl_Titulo = new javax.swing.JLabel();
        lbl_Producto = new javax.swing.JLabel();
        lbl_StockActual = new javax.swing.JLabel();
        lbl_StockNuevo = new javax.swing.JLabel();
        txt_StockActual = new javax.swing.JTextField();
        txt_StockNuevo = new javax.swing.JTextField();
        comboBox_Producto = new javax.swing.JComboBox<>();
        jButton1 = new javax.swing.JButton();
        lbl_Walpaper = new javax.swing.JLabel();

        setClosable(true);
        setIconifiable(true);
        setResizable(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lbl_Titulo.setFont(new java.awt.Font("Impact", 0, 18)); // NOI18N
        lbl_Titulo.setForeground(new java.awt.Color(255, 255, 255));
        lbl_Titulo.setText("Actualizar Stock de Productos");
        getContentPane().add(lbl_Titulo, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 20, -1, -1));

        lbl_Producto.setFont(new java.awt.Font("Impact", 0, 14)); // NOI18N
        lbl_Producto.setForeground(new java.awt.Color(255, 255, 255));
        lbl_Producto.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lbl_Producto.setText("Producto:");
        getContentPane().add(lbl_Producto, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 60, 80, -1));

        lbl_StockActual.setFont(new java.awt.Font("Impact", 0, 14)); // NOI18N
        lbl_StockActual.setForeground(new java.awt.Color(255, 255, 255));
        lbl_StockActual.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lbl_StockActual.setText("Stock Actual:");
        getContentPane().add(lbl_StockActual, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 100, 80, -1));

        lbl_StockNuevo.setFont(new java.awt.Font("Impact", 0, 14)); // NOI18N
        lbl_StockNuevo.setForeground(new java.awt.Color(255, 255, 255));
        lbl_StockNuevo.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lbl_StockNuevo.setText("Stock Nuevo:");
        getContentPane().add(lbl_StockNuevo, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 140, 80, -1));

        txt_StockActual.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 14)); // NOI18N
        txt_StockActual.setEnabled(false);
        getContentPane().add(txt_StockActual, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 100, 170, -1));

        txt_StockNuevo.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 14)); // NOI18N
        getContentPane().add(txt_StockNuevo, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 140, 170, -1));

        comboBox_Producto.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccione producto:", " " }));
        comboBox_Producto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboBox_ProductoActionPerformed(evt);
            }
        });
        getContentPane().add(comboBox_Producto, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 60, 170, -1));

        jButton1.setBackground(new java.awt.Color(0, 204, 0));
        jButton1.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 14)); // NOI18N
        jButton1.setText("Actualizar");
        jButton1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 190, 100, 25));

        lbl_Walpaper.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/fondo3_1.jpg"))); // NOI18N
        getContentPane().add(lbl_Walpaper, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 390, 270));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void comboBox_ProductoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboBox_ProductoActionPerformed
        // TODO add your handling code here:
        MostrarStock();
    }//GEN-LAST:event_comboBox_ProductoActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        //validamos seleccion del producto
        if (!comboBox_Producto.getSelectedItem().equals("Seleccione producto:")) {
            //Validamos espacios vacios
            if (!txt_StockNuevo.getText().isEmpty()) {
                //validamos que el usuario no ingrese otros caracteres que no sean numericos
                boolean validacion = validar(txt_StockNuevo.getText().trim());
                if (validacion == true) {
                    //validar que la cantidad sea mayor cero (0)
                    if (Integer.parseInt(txt_StockNuevo.getText()) > 0) {

                        Producto producto = new Producto();
                        Ctrl_Producto controlProducto = new Ctrl_Producto();
                        int stockActual = Integer.parseInt(txt_StockActual.getText().trim());
                        int stockNuevo = Integer.parseInt(txt_StockNuevo.getText().trim());

                        stockNuevo = stockActual + stockNuevo;
                        producto.setCantidad(stockNuevo);
                        if (controlProducto.actualizarStock(producto, idProducto)) {
                            JOptionPane.showMessageDialog(null, "Stock Actualizado");
                            comboBox_Producto.setSelectedItem("Seleccione producto:");
                            txt_StockActual.setText("");
                            txt_StockNuevo.setText("");
                            CargarProductos();
                        } else {
                            JOptionPane.showMessageDialog(null, "Error al Actualizar Stock");
                        }
                    } else {
                        JOptionPane.showMessageDialog(null, "La cantidad no puede ser cero ni negativa");
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "En la cantidad no se admiten caracteres no numericos");
                }
            } else {
                JOptionPane.showMessageDialog(null, "Ingrese una nueva cantidad para sumar el stock del producto");
            }
        } else {
            JOptionPane.showMessageDialog(null, "Seleccione un producto");
        }
    }//GEN-LAST:event_jButton1ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> comboBox_Producto;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel lbl_Producto;
    private javax.swing.JLabel lbl_StockActual;
    private javax.swing.JLabel lbl_StockNuevo;
    private javax.swing.JLabel lbl_Titulo;
    private javax.swing.JLabel lbl_Walpaper;
    private javax.swing.JTextField txt_StockActual;
    private javax.swing.JTextField txt_StockNuevo;
    // End of variables declaration//GEN-END:variables

    //Metodo para caragar los productos en el jComboBox
    private void CargarProductos() {

        Connection cn = conexion.Conexion_BD.conectar();
        String sql = "SELECT * FROM tb_producto";
        Statement st;
        try {

            st = cn.createStatement();
            ResultSet rs = st.executeQuery(sql);
            comboBox_Producto.removeAllItems();
            comboBox_Producto.addItem("Seleccione producto:");
            while (rs.next()) {
                comboBox_Producto.addItem(rs.getString("nombre"));
            }

        } catch (SQLException e) {
            System.out.println("Error al cargar los productos en: " + e);
        }
    }

    private void MostrarStock() {
        
        try {
            Connection cn = conexion.Conexion_BD.conectar();
            String sql = "select * from tb_producto where nombre = '" + comboBox_Producto.getSelectedItem() + "'";
            Statement st;
            st = cn.createStatement();
            ResultSet rs = st.executeQuery(sql);

            if (rs.next()) {
                idProducto = rs.getInt("idProducto");
                cantidad = rs.getInt("cantidad");
                txt_StockActual.setText(String.valueOf(cantidad));
            } else {
                txt_StockActual.setText("");
            }
        } catch (SQLException e) {
            System.out.println("Error al obtener stock del producto en: " + e);
        }
    }

    //metodo de validacion de caracteres no numericos
    private boolean validar(String valor) {
        int num;
        try {
            num = Integer.parseInt(valor);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }

}
