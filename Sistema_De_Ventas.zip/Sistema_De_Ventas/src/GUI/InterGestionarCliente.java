package GUI;

import controladores.Ctrl_Cliente;
import java.awt.Dimension;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.*;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import modelo.Cliente;

/**
 *
 *@author Edgar JPC (Yacu)
 */
public class InterGestionarCliente extends javax.swing.JInternalFrame {

    private int idCliente;

    public InterGestionarCliente() {
        initComponents();
        setSize(new Dimension(900, 500));
        setTitle("Gestionar Clientes");
        CargarTablaClientes();
        //Insertar imagen en el label
        ImageIcon walpaper = new ImageIcon("src/img/fondo3.jpg");
        Icon icono = new ImageIcon(walpaper.getImage().getScaledInstance(900, 500, WIDTH));
        lbl_Walpaper.setIcon(icono);
        repaint();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblAdminCliente = new javax.swing.JLabel();
        pnl1 = new javax.swing.JPanel();
        scrolTabla = new javax.swing.JScrollPane();
        table_Clientes = new javax.swing.JTable();
        pnl2 = new javax.swing.JPanel();
        btn_Actualizar = new javax.swing.JButton();
        btn_Eliminar = new javax.swing.JButton();
        pnl3 = new javax.swing.JPanel();
        lbl_Nombre = new javax.swing.JLabel();
        txtNombre = new javax.swing.JTextField();
        lbl_Apellido = new javax.swing.JLabel();
        lbl_Cedula = new javax.swing.JLabel();
        lbl_Descripcion = new javax.swing.JLabel();
        lbl_Direccion = new javax.swing.JLabel();
        txtTelefono = new javax.swing.JTextField();
        txtCedula = new javax.swing.JTextField();
        txtDireccion = new javax.swing.JTextField();
        txtApellido = new javax.swing.JTextField();
        lbl_Walpaper = new javax.swing.JLabel();

        setClosable(true);
        setIconifiable(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblAdminCliente.setFont(new java.awt.Font("Impact", 0, 18)); // NOI18N
        lblAdminCliente.setForeground(new java.awt.Color(255, 255, 255));
        lblAdminCliente.setText("Administrar Cliente");
        getContentPane().add(lblAdminCliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 20, -1, -1));

        pnl1.setBackground(new java.awt.Color(255, 255, 255));
        pnl1.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        pnl1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        table_Clientes.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        scrolTabla.setViewportView(table_Clientes);

        pnl1.add(scrolTabla, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 730, 270));

        getContentPane().add(pnl1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 50, 730, 270));

        pnl2.setBackground(new java.awt.Color(255, 255, 255));
        pnl2.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        pnl2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btn_Actualizar.setBackground(new java.awt.Color(51, 204, 0));
        btn_Actualizar.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 12)); // NOI18N
        btn_Actualizar.setText("Actualizar");
        btn_Actualizar.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_Actualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_ActualizarActionPerformed(evt);
            }
        });
        pnl2.add(btn_Actualizar, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 90, -1));

        btn_Eliminar.setBackground(new java.awt.Color(255, 51, 51));
        btn_Eliminar.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 12)); // NOI18N
        btn_Eliminar.setText("Eliminar");
        btn_Eliminar.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_Eliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_EliminarActionPerformed(evt);
            }
        });
        pnl2.add(btn_Eliminar, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 50, 90, -1));

        getContentPane().add(pnl2, new org.netbeans.lib.awtextra.AbsoluteConstraints(750, 50, 130, 270));

        pnl3.setBackground(new java.awt.Color(255, 255, 255));
        pnl3.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        pnl3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lbl_Nombre.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 14)); // NOI18N
        lbl_Nombre.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lbl_Nombre.setText("Nombre:");
        pnl3.add(lbl_Nombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 80, -1));

        txtNombre.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 12)); // NOI18N
        pnl3.add(txtNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 10, 170, -1));

        lbl_Apellido.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 14)); // NOI18N
        lbl_Apellido.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lbl_Apellido.setText("Telefono:");
        pnl3.add(lbl_Apellido, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 40, 80, -1));

        lbl_Cedula.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 14)); // NOI18N
        lbl_Cedula.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lbl_Cedula.setText("Apellido:");
        pnl3.add(lbl_Cedula, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 10, 80, -1));

        lbl_Descripcion.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 14)); // NOI18N
        lbl_Descripcion.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lbl_Descripcion.setText("Direccion:");
        pnl3.add(lbl_Descripcion, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 40, 80, -1));

        lbl_Direccion.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 14)); // NOI18N
        lbl_Direccion.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lbl_Direccion.setText("Cedula:");
        pnl3.add(lbl_Direccion, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 10, 80, -1));

        txtTelefono.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 12)); // NOI18N
        pnl3.add(txtTelefono, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 40, 170, -1));

        txtCedula.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 12)); // NOI18N
        pnl3.add(txtCedula, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 10, 170, -1));

        txtDireccion.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 12)); // NOI18N
        pnl3.add(txtDireccion, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 40, 170, -1));

        txtApellido.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 12)); // NOI18N
        pnl3.add(txtApellido, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 10, 170, -1));

        getContentPane().add(pnl3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 330, 870, 100));

        lbl_Walpaper.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/fondo222.jpg"))); // NOI18N
        getContentPane().add(lbl_Walpaper, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 890, 470));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn_ActualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_ActualizarActionPerformed
        if (txtNombre.getText().isEmpty() && txtCedula.getText().isEmpty()
                && txtCedula.getText().isEmpty() && txtTelefono.getText().isEmpty() && txtDireccion.getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "¡Completa todos los campos!");
        } else {

            Cliente cliente = new Cliente();
            Ctrl_Cliente controlCliente = new Ctrl_Cliente();

            cliente.setNombre(txtNombre.getText().trim());
            cliente.setApellido(txtApellido.getText().trim());
            cliente.setCedula(txtCedula.getText().trim());
            cliente.setTelefono(txtTelefono.getText().trim());
            cliente.setDireccion(txtDireccion.getText().trim());

            if (controlCliente.actualizar(cliente, idCliente)) {
                JOptionPane.showMessageDialog(null, "¡Datos del cliente actualizados!");
                CargarTablaClientes();
                Limpiar();
            } else {
                JOptionPane.showMessageDialog(null, "¡Error al actualizar!");
            }

        }

    }//GEN-LAST:event_btn_ActualizarActionPerformed

    private void btn_EliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_EliminarActionPerformed

        Ctrl_Cliente controlCliente = new Ctrl_Cliente();
        if (idCliente == 0) {
            JOptionPane.showMessageDialog(null, "¡Seleccione un cliente!");
        } else {
            if (!controlCliente.eliminar(idCliente)) {
                JOptionPane.showMessageDialog(null, "¡Cliente Eliminado!");
                CargarTablaClientes();
                Limpiar();
            } else {
                JOptionPane.showMessageDialog(null, "¡Error al eliminar cliente!");
                Limpiar();
            }
        }
    }//GEN-LAST:event_btn_EliminarActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_Actualizar;
    private javax.swing.JButton btn_Eliminar;
    private javax.swing.JLabel lblAdminCliente;
    private javax.swing.JLabel lbl_Apellido;
    private javax.swing.JLabel lbl_Cedula;
    private javax.swing.JLabel lbl_Descripcion;
    private javax.swing.JLabel lbl_Direccion;
    private javax.swing.JLabel lbl_Nombre;
    private javax.swing.JLabel lbl_Walpaper;
    private javax.swing.JPanel pnl1;
    private javax.swing.JPanel pnl2;
    private javax.swing.JPanel pnl3;
    public static javax.swing.JScrollPane scrolTabla;
    public static javax.swing.JTable table_Clientes;
    private javax.swing.JTextField txtApellido;
    private javax.swing.JTextField txtCedula;
    private javax.swing.JTextField txtDireccion;
    private javax.swing.JTextField txtNombre;
    private javax.swing.JTextField txtTelefono;
    // End of variables declaration//GEN-END:variables

    
    //Metodo para mostrar todos los clientes registrados
    private void CargarTablaClientes() {
        Connection con = conexion.Conexion_BD.conectar();
        DefaultTableModel model = new DefaultTableModel();
        String sql = "SELECT * FROM tb_cliente";
        Statement st;
        try {
            st = con.createStatement();
            ResultSet rs = st.executeQuery(sql);
            InterGestionarCliente.table_Clientes = new JTable(model);
            InterGestionarCliente.scrolTabla.setViewportView(InterGestionarCliente.table_Clientes);

            model.addColumn("N°");//ID
            model.addColumn("nombre");
            model.addColumn("apellido");
            model.addColumn("cedula");
            model.addColumn("telefono");
            model.addColumn("direccion");
            model.addColumn("estado");

            while (rs.next()) {
                Object fila[] = new Object[7];
                for (int i = 0; i < 7; i++) {
                    fila[i] = rs.getObject(i + 1);
                }
                model.addRow(fila);
            }
            con.close();
        } catch (SQLException e) {
            System.out.println("Error al llenar la tabla clientes: " + e);
        }
        //evento para obtener campo al cual el usuario da click
        //y obtener la interfaz que mostrara la informacion general
        table_Clientes.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int fila_point = table_Clientes.rowAtPoint(e.getPoint());
                int columna_point = 0;

                if (fila_point > -1) {
                    idCliente = (int) model.getValueAt(fila_point, columna_point);
                    EnviarDatosCliente(idCliente);//metodo
                }
            }
        });
    }

    //Metodo que envia datos seleccionados
    private void EnviarDatosCliente(int idCliente) {
        try {
            Connection con = conexion.Conexion_BD.conectar();
            PreparedStatement pst = con.prepareStatement(
                    "SELECT * FROM tb_cliente WHERE idCliente = '" + idCliente + "'");
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                txtNombre.setText(rs.getString("nombre"));
                txtApellido.setText(rs.getString("apellido"));
                txtCedula.setText(rs.getString("cedula"));
                txtTelefono.setText(rs.getString("telefono"));
                txtDireccion.setText(rs.getString("direccion"));
            }
            con.close();
        } catch (SQLException e) {
            System.out.println("Error al seleccionar cliente: " + e);
        }
    }

    //Metodo para cargar las categorias JcomboBox
    private void Limpiar() {
        txtNombre.setText("");
        txtTelefono.setText("");
        txtCedula.setText("");
        txtDireccion.setText("");
        txtApellido.setText("");
    }
}
