package GUI;

import controladores.Ctrl_Categoria;
import java.awt.Dimension;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.*;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import modelo.Categoria;

/**
 *
 * @author jonat
 */
public class InterGestionarCategoria extends javax.swing.JInternalFrame {

    private int idCategoria;

    public InterGestionarCategoria() {
        initComponents();
        setSize(new Dimension(600, 400));
        setTitle("Gestionar Categorias");
        cargarTablaCategoria();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblAdminCategorias = new javax.swing.JLabel();
        pnl1 = new javax.swing.JPanel();
        scrolTabla = new javax.swing.JScrollPane();
        table_Categorias = new javax.swing.JTable();
        pnl2 = new javax.swing.JPanel();
        btn_Actualizar = new javax.swing.JButton();
        btn_Eliminar = new javax.swing.JButton();
        pnl3 = new javax.swing.JPanel();
        lblDescripcion = new javax.swing.JLabel();
        txtDescripcion = new javax.swing.JTextField();
        lblWallpaper = new javax.swing.JLabel();

        setClosable(true);
        setIconifiable(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblAdminCategorias.setFont(new java.awt.Font("Impact", 0, 18)); // NOI18N
        lblAdminCategorias.setForeground(new java.awt.Color(255, 255, 255));
        lblAdminCategorias.setText("Administrar Categorias");
        getContentPane().add(lblAdminCategorias, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 10, -1, -1));

        pnl1.setBackground(new java.awt.Color(255, 255, 255));
        pnl1.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        pnl1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        table_Categorias.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        scrolTabla.setViewportView(table_Categorias);

        pnl1.add(scrolTabla, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 350, 250));

        getContentPane().add(pnl1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 60, 350, 250));

        pnl2.setBackground(new java.awt.Color(255, 255, 255));
        pnl2.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        pnl2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btn_Actualizar.setBackground(new java.awt.Color(51, 204, 0));
        btn_Actualizar.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 12)); // NOI18N
        btn_Actualizar.setText("Actualizar");
        btn_Actualizar.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_Actualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_ActualizarActionPerformed(evt);
            }
        });
        pnl2.add(btn_Actualizar, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 90, -1));

        btn_Eliminar.setBackground(new java.awt.Color(255, 51, 51));
        btn_Eliminar.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 12)); // NOI18N
        btn_Eliminar.setText("Eliminar");
        btn_Eliminar.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_Eliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_EliminarActionPerformed(evt);
            }
        });
        pnl2.add(btn_Eliminar, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 40, 90, -1));

        getContentPane().add(pnl2, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 60, 130, 80));

        pnl3.setBackground(new java.awt.Color(255, 255, 255));
        pnl3.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        pnl3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblDescripcion.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 14)); // NOI18N
        lblDescripcion.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        lblDescripcion.setText("Descripcion:");
        pnl3.add(lblDescripcion, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, -1));

        txtDescripcion.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 12)); // NOI18N
        pnl3.add(txtDescripcion, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 40, 150, -1));

        getContentPane().add(pnl3, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 160, 190, 80));

        lblWallpaper.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/fondo3.jpg"))); // NOI18N
        getContentPane().add(lblWallpaper, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 590, 370));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn_ActualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_ActualizarActionPerformed
        // TODO add your handling code here:
        if (!txtDescripcion.getText().isEmpty()) {
            Categoria categoria = new Categoria();
            Ctrl_Categoria controlCategoria = new Ctrl_Categoria();
            categoria.setDescripcion(txtDescripcion.getText().trim());
            if (controlCategoria.actualizar(categoria, idCategoria)) {
                JOptionPane.showMessageDialog(null, "Categoria actualizada");
                txtDescripcion.setText("");
                cargarTablaCategoria();
            } else {
                JOptionPane.showMessageDialog(null, "Error al actualizar la categoria");
            }
        } else {
            JOptionPane.showMessageDialog(null, "Seleccione una categoria");
        }
    }//GEN-LAST:event_btn_ActualizarActionPerformed

    private void btn_EliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_EliminarActionPerformed
        
        if (!txtDescripcion.getText().isEmpty()) {
            Categoria categoria = new Categoria();
            Ctrl_Categoria controlCategoria = new Ctrl_Categoria();
            categoria.setDescripcion(txtDescripcion.getText().trim());
            
            if (controlCategoria.borrar(idCategoria)) {
                JOptionPane.showMessageDialog(null, "Categoria eliminada");
                txtDescripcion.setText("");
                cargarTablaCategoria();
            } else {
                JOptionPane.showMessageDialog(null, "Error al eliminar la categoria"); 
            }
        } else {
            JOptionPane.showMessageDialog(null, "Seleccione una categoria");
        }
    }//GEN-LAST:event_btn_EliminarActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_Actualizar;
    private javax.swing.JButton btn_Eliminar;
    private javax.swing.JLabel lblAdminCategorias;
    private javax.swing.JLabel lblDescripcion;
    private javax.swing.JLabel lblWallpaper;
    private javax.swing.JPanel pnl1;
    private javax.swing.JPanel pnl2;
    private javax.swing.JPanel pnl3;
    public static javax.swing.JScrollPane scrolTabla;
    public static javax.swing.JTable table_Categorias;
    private javax.swing.JTextField txtDescripcion;
    // End of variables declaration//GEN-END:variables

    //Metodo para mostrar todas las categorias registradas:
    private void cargarTablaCategoria() {
        Connection con = conexion.Conexion_BD.conectar();
        DefaultTableModel model1 = new DefaultTableModel();
        String SQL = "SELECT idCategoria, descripcion, estado FROM tb_Categoria";
        Statement st;
        try {
            st = con.createStatement();
            ResultSet rs = st.executeQuery(SQL);
            InterGestionarCategoria.table_Categorias = new JTable(model1);
            InterGestionarCategoria.scrolTabla.setViewportView(InterGestionarCategoria.table_Categorias);
            model1.addColumn("idCategoria");
            model1.addColumn("descripcion");
            model1.addColumn("Estado");

            while (rs.next()) {
                Object fila[] = new Object[3];
                for (int i = 0; i < 3; i++) {
                    fila[i] = rs.getObject(i + 1);
                }
                model1.addRow(fila);
            }
            con.close();
        } catch (SQLException e) {
            System.out.println("Error al llenar la tabla categoria " + e);
        }

        table_Categorias.addMouseListener(new MouseAdapter() {

            @Override
            public void mouseClicked(MouseEvent e) {
                int fila_point = table_Categorias.rowAtPoint(e.getPoint());
                int columna_point = 0;

                if (fila_point >= -1) {
                    idCategoria = (int) model1.getValueAt(fila_point, columna_point);
                    enviarDatosCategoria(idCategoria);
                }
            }
        });
    }

    public void enviarDatosCategoria(int idCategoria) {
        try {
            Connection con = conexion.Conexion_BD.conectar();
            PreparedStatement ps = con.prepareStatement("SELECT * FROM tb_categoria WHERE idCategoria = '" + idCategoria + "'");
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                txtDescripcion.setText(rs.getString("descripcion"));
            }
            con.close();

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al cargar categoria");
        }
    }
}
