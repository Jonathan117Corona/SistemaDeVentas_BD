package GUI;

import controladores.Reportes;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.Toolkit;
import javax.swing.JDesktopPane;

/**
 *
 * @author jonat
 */
public class FrmMenu extends javax.swing.JFrame {
    
  
    public static JDesktopPane jDesktopPane_menu;

    public FrmMenu() {
        initComponents();
        this.setSize(new Dimension(1200, 700));
        this.setExtendedState(this.MAXIMIZED_BOTH);
        this.setLocationRelativeTo(null);
        this.setTitle("Woow Games");

        this.setLayout(null);
        jDesktopPane_menu = new JDesktopPane();

        int ancho = java.awt.Toolkit.getDefaultToolkit().getScreenSize().width;
        int alto = java.awt.Toolkit.getDefaultToolkit().getScreenSize().height;
        this.jDesktopPane_menu.setBounds(0, 0, ancho, (alto - 110));
        this.add(jDesktopPane_menu);

    }
    
    public Image getIconImage(){
        Image retValue = Toolkit.getDefaultToolkit().getImage(ClassLoader.getSystemResource("img/ventas.png"));
        return retValue;
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        MenuWoowGames = new javax.swing.JMenuBar();
        Menu_Usuario = new javax.swing.JMenu();
        nuevoUsuario = new javax.swing.JMenuItem();
        gestionarUsuario = new javax.swing.JMenuItem();
        Menu_Producto = new javax.swing.JMenu();
        nuevoProducto = new javax.swing.JMenuItem();
        gestionarProducto = new javax.swing.JMenuItem();
        actualizarStock = new javax.swing.JMenuItem();
        Menu_Cliente = new javax.swing.JMenu();
        nuevoCliente = new javax.swing.JMenuItem();
        gestionarCliente = new javax.swing.JMenuItem();
        Menu_Categoria = new javax.swing.JMenu();
        nuevaCategoria = new javax.swing.JMenuItem();
        gestionarCategoria = new javax.swing.JMenuItem();
        Menu_Factura = new javax.swing.JMenu();
        nuevaVenta = new javax.swing.JMenuItem();
        gestionarVenta = new javax.swing.JMenuItem();
        Menu_Reportes = new javax.swing.JMenu();
        reporteCliente = new javax.swing.JMenuItem();
        reporteCategoria = new javax.swing.JMenuItem();
        reporteProducto = new javax.swing.JMenuItem();
        reporteVenta = new javax.swing.JMenuItem();
        Menu_Historial = new javax.swing.JMenu();
        verHistorial = new javax.swing.JMenuItem();
        Menu_CerrarSesion = new javax.swing.JMenu();
        cerrarSesion = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        setIconImage(getIconImage());
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Menu_Usuario.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/usuario.png"))); // NOI18N
        Menu_Usuario.setText("Usuario");
        Menu_Usuario.setFont(new java.awt.Font("Impact", 0, 18)); // NOI18N
        Menu_Usuario.setPreferredSize(new java.awt.Dimension(150, 50));

        nuevoUsuario.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 14)); // NOI18N
        nuevoUsuario.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/nuevo-cliente.png"))); // NOI18N
        nuevoUsuario.setText("Nuevo Usuario");
        nuevoUsuario.setPreferredSize(new java.awt.Dimension(200, 30));
        nuevoUsuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nuevoUsuarioActionPerformed(evt);
            }
        });
        Menu_Usuario.add(nuevoUsuario);

        gestionarUsuario.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 14)); // NOI18N
        gestionarUsuario.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/configuraciones.png"))); // NOI18N
        gestionarUsuario.setText("Gestionar Usuario");
        gestionarUsuario.setPreferredSize(new java.awt.Dimension(200, 30));
        gestionarUsuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                gestionarUsuarioActionPerformed(evt);
            }
        });
        Menu_Usuario.add(gestionarUsuario);

        MenuWoowGames.add(Menu_Usuario);

        Menu_Producto.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/producto.png"))); // NOI18N
        Menu_Producto.setText("Producto");
        Menu_Producto.setFont(new java.awt.Font("Impact", 0, 18)); // NOI18N
        Menu_Producto.setPreferredSize(new java.awt.Dimension(150, 50));

        nuevoProducto.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 14)); // NOI18N
        nuevoProducto.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/nuevo-producto.png"))); // NOI18N
        nuevoProducto.setText("Nuevo Producto");
        nuevoProducto.setPreferredSize(new java.awt.Dimension(200, 30));
        nuevoProducto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nuevoProductoActionPerformed(evt);
            }
        });
        Menu_Producto.add(nuevoProducto);

        gestionarProducto.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 14)); // NOI18N
        gestionarProducto.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/producto.png"))); // NOI18N
        gestionarProducto.setText("Gestionar Producto");
        gestionarProducto.setPreferredSize(new java.awt.Dimension(200, 30));
        gestionarProducto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                gestionarProductoActionPerformed(evt);
            }
        });
        Menu_Producto.add(gestionarProducto);

        actualizarStock.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 14)); // NOI18N
        actualizarStock.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/nuevo.png"))); // NOI18N
        actualizarStock.setText("Actualizar Stock");
        actualizarStock.setPreferredSize(new java.awt.Dimension(200, 30));
        actualizarStock.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                actualizarStockActionPerformed(evt);
            }
        });
        Menu_Producto.add(actualizarStock);

        MenuWoowGames.add(Menu_Producto);

        Menu_Cliente.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/cliente.png"))); // NOI18N
        Menu_Cliente.setText("Cliente");
        Menu_Cliente.setFont(new java.awt.Font("Impact", 0, 18)); // NOI18N
        Menu_Cliente.setPreferredSize(new java.awt.Dimension(150, 50));

        nuevoCliente.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 14)); // NOI18N
        nuevoCliente.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/nuevo-cliente.png"))); // NOI18N
        nuevoCliente.setText("Nuevo Cliente");
        nuevoCliente.setPreferredSize(new java.awt.Dimension(200, 30));
        nuevoCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nuevoClienteActionPerformed(evt);
            }
        });
        Menu_Cliente.add(nuevoCliente);

        gestionarCliente.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 14)); // NOI18N
        gestionarCliente.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/cliente.png"))); // NOI18N
        gestionarCliente.setText("Gestionar Cliente");
        gestionarCliente.setPreferredSize(new java.awt.Dimension(200, 30));
        gestionarCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                gestionarClienteActionPerformed(evt);
            }
        });
        Menu_Cliente.add(gestionarCliente);

        MenuWoowGames.add(Menu_Cliente);

        Menu_Categoria.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/categorias.png"))); // NOI18N
        Menu_Categoria.setText("Categoria");
        Menu_Categoria.setFont(new java.awt.Font("Impact", 0, 18)); // NOI18N
        Menu_Categoria.setPreferredSize(new java.awt.Dimension(150, 50));

        nuevaCategoria.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 14)); // NOI18N
        nuevaCategoria.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/nuevo.png"))); // NOI18N
        nuevaCategoria.setText("Nueva Categoria");
        nuevaCategoria.setPreferredSize(new java.awt.Dimension(200, 30));
        nuevaCategoria.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nuevaCategoriaActionPerformed(evt);
            }
        });
        Menu_Categoria.add(nuevaCategoria);

        gestionarCategoria.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 14)); // NOI18N
        gestionarCategoria.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/categorias.png"))); // NOI18N
        gestionarCategoria.setText("Gestionar Categoria");
        gestionarCategoria.setPreferredSize(new java.awt.Dimension(200, 30));
        gestionarCategoria.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                gestionarCategoriaActionPerformed(evt);
            }
        });
        Menu_Categoria.add(gestionarCategoria);

        MenuWoowGames.add(Menu_Categoria);

        Menu_Factura.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/carrito.png"))); // NOI18N
        Menu_Factura.setText("Factura");
        Menu_Factura.setFont(new java.awt.Font("Impact", 0, 18)); // NOI18N
        Menu_Factura.setPreferredSize(new java.awt.Dimension(150, 50));

        nuevaVenta.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 14)); // NOI18N
        nuevaVenta.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/anadir.png"))); // NOI18N
        nuevaVenta.setText("Nueva Venta");
        nuevaVenta.setPreferredSize(new java.awt.Dimension(200, 30));
        nuevaVenta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nuevaVentaActionPerformed(evt);
            }
        });
        Menu_Factura.add(nuevaVenta);

        gestionarVenta.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 14)); // NOI18N
        gestionarVenta.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/configuraciones.png"))); // NOI18N
        gestionarVenta.setText("Gestionar Ventas");
        gestionarVenta.setPreferredSize(new java.awt.Dimension(200, 30));
        gestionarVenta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                gestionarVentaActionPerformed(evt);
            }
        });
        Menu_Factura.add(gestionarVenta);

        MenuWoowGames.add(Menu_Factura);

        Menu_Reportes.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/reportes.png"))); // NOI18N
        Menu_Reportes.setText("Reportes");
        Menu_Reportes.setFont(new java.awt.Font("Impact", 0, 18)); // NOI18N
        Menu_Reportes.setPreferredSize(new java.awt.Dimension(150, 50));

        reporteCliente.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 14)); // NOI18N
        reporteCliente.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/reporte1.png"))); // NOI18N
        reporteCliente.setText("Reporte Cliente");
        reporteCliente.setPreferredSize(new java.awt.Dimension(200, 30));
        reporteCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                reporteClienteActionPerformed(evt);
            }
        });
        Menu_Reportes.add(reporteCliente);

        reporteCategoria.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 14)); // NOI18N
        reporteCategoria.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/reporte1.png"))); // NOI18N
        reporteCategoria.setText("Reporte Categoria");
        reporteCategoria.setPreferredSize(new java.awt.Dimension(200, 30));
        reporteCategoria.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                reporteCategoriaActionPerformed(evt);
            }
        });
        Menu_Reportes.add(reporteCategoria);

        reporteProducto.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 14)); // NOI18N
        reporteProducto.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/reporte1.png"))); // NOI18N
        reporteProducto.setText("Reporte Producto");
        reporteProducto.setPreferredSize(new java.awt.Dimension(200, 30));
        reporteProducto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                reporteProductoActionPerformed(evt);
            }
        });
        Menu_Reportes.add(reporteProducto);

        reporteVenta.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 14)); // NOI18N
        reporteVenta.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/reporte1.png"))); // NOI18N
        reporteVenta.setText("Reporte Venta");
        reporteVenta.setPreferredSize(new java.awt.Dimension(200, 30));
        reporteVenta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                reporteVentaActionPerformed(evt);
            }
        });
        Menu_Reportes.add(reporteVenta);

        MenuWoowGames.add(Menu_Reportes);

        Menu_Historial.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/historial1.png"))); // NOI18N
        Menu_Historial.setText("Historial");
        Menu_Historial.setFont(new java.awt.Font("Impact", 0, 18)); // NOI18N
        Menu_Historial.setPreferredSize(new java.awt.Dimension(150, 50));

        verHistorial.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 14)); // NOI18N
        verHistorial.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/historial1.png"))); // NOI18N
        verHistorial.setText("Ver historial");
        verHistorial.setPreferredSize(new java.awt.Dimension(200, 30));
        verHistorial.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                verHistorialActionPerformed(evt);
            }
        });
        Menu_Historial.add(verHistorial);

        MenuWoowGames.add(Menu_Historial);

        Menu_CerrarSesion.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/cerrar-sesion.png"))); // NOI18N
        Menu_CerrarSesion.setText("Cerrar Sesion");
        Menu_CerrarSesion.setFont(new java.awt.Font("Impact", 0, 18)); // NOI18N
        Menu_CerrarSesion.setPreferredSize(new java.awt.Dimension(150, 50));

        cerrarSesion.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 14)); // NOI18N
        cerrarSesion.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/cerrar-sesion.png"))); // NOI18N
        cerrarSesion.setText("Cerrar Sesion");
        cerrarSesion.setPreferredSize(new java.awt.Dimension(200, 30));
        cerrarSesion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cerrarSesionActionPerformed(evt);
            }
        });
        Menu_CerrarSesion.add(cerrarSesion);

        MenuWoowGames.add(Menu_CerrarSesion);

        setJMenuBar(MenuWoowGames);

        pack();
    }// </editor-fold>//GEN-END:initComponents
    
    private void nuevoUsuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nuevoUsuarioActionPerformed
        // TODO add your handling code here:
        InterUsuario vU = new InterUsuario();
        jDesktopPane_menu.add(vU);
        vU.setVisible(true);
    }//GEN-LAST:event_nuevoUsuarioActionPerformed

    private void nuevaCategoriaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nuevaCategoriaActionPerformed
        // TODO add your handling code here:
        InterCategoria vC = new InterCategoria();
        jDesktopPane_menu.add(vC);
        vC.setVisible(true);
    }//GEN-LAST:event_nuevaCategoriaActionPerformed

    private void gestionarCategoriaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_gestionarCategoriaActionPerformed
        // TODO add your handling code here:
        InterGestionarCategoria vGC = new InterGestionarCategoria();
        jDesktopPane_menu.add(vGC);
        vGC.setVisible(true);
    }//GEN-LAST:event_gestionarCategoriaActionPerformed

    private void nuevoProductoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nuevoProductoActionPerformed
        // TODO add your handling code here:
        InterProducto vP = new InterProducto();
        jDesktopPane_menu.add(vP);
        vP.setVisible(true);
    }//GEN-LAST:event_nuevoProductoActionPerformed

    private void gestionarProductoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_gestionarProductoActionPerformed
        // TODO add your handling code here:
        InterGestionarProducto vGP = new InterGestionarProducto();
        jDesktopPane_menu.add(vGP);
        vGP.setVisible(true);
    }//GEN-LAST:event_gestionarProductoActionPerformed

    private void cerrarSesionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cerrarSesionActionPerformed
        // TODO add your handling code here:
        FrmLogin vL = new FrmLogin();
        dispose();
        vL.setVisible(true);
    }//GEN-LAST:event_cerrarSesionActionPerformed

    private void nuevoClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nuevoClienteActionPerformed
        // TODO add your handling code here:
        InterCliente vCl = new InterCliente();
        jDesktopPane_menu.add(vCl);
        vCl.setVisible(true);
    }//GEN-LAST:event_nuevoClienteActionPerformed

    private void gestionarClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_gestionarClienteActionPerformed
        // TODO add your handling code here:
        InterGestionarCliente vGC = new InterGestionarCliente();
        jDesktopPane_menu.add(vGC);
        vGC.setVisible(true);
    }//GEN-LAST:event_gestionarClienteActionPerformed

    private void actualizarStockActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_actualizarStockActionPerformed
        // TODO add your handling code here:
        InterActualizarStock vAS = new InterActualizarStock();
        jDesktopPane_menu.add(vAS);
        vAS.setVisible(true);
    }//GEN-LAST:event_actualizarStockActionPerformed

    private void gestionarUsuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_gestionarUsuarioActionPerformed
        // TODO add your handling code here:
        InterGestionarUsuario vGU = new InterGestionarUsuario();
        jDesktopPane_menu.add(vGU);
        vGU.setVisible(true);
    }//GEN-LAST:event_gestionarUsuarioActionPerformed

    private void nuevaVentaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nuevaVentaActionPerformed
        // TODO add your handling code here:
        InterFacturacion vF = new InterFacturacion();
        jDesktopPane_menu.add(vF);
        vF.setVisible(true);
    }//GEN-LAST:event_nuevaVentaActionPerformed

    private void gestionarVentaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_gestionarVentaActionPerformed
        // TODO add your handling code here:
        InterGestionarVentas vGV = new InterGestionarVentas();
        jDesktopPane_menu.add(vGV);
        vGV.setVisible(true);
    }//GEN-LAST:event_gestionarVentaActionPerformed

    private void reporteClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_reporteClienteActionPerformed
        // TODO add your handling code here:
        Reportes reporteCli = new Reportes();
        reporteCli.reporteClientes();
    }//GEN-LAST:event_reporteClienteActionPerformed

    private void reporteCategoriaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_reporteCategoriaActionPerformed
        // TODO add your handling code here:
        Reportes reporteCat = new Reportes();
        reporteCat.reporteCategorias();
    }//GEN-LAST:event_reporteCategoriaActionPerformed

    private void reporteProductoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_reporteProductoActionPerformed
        // TODO add your handling code here:
        Reportes reporteProd = new Reportes();
        reporteProd.reporteProductos();
    }//GEN-LAST:event_reporteProductoActionPerformed

    private void reporteVentaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_reporteVentaActionPerformed
        // TODO add your handling code here:
        Reportes reporteVen = new Reportes();
        reporteVen.reporteVentas();
    }//GEN-LAST:event_reporteVentaActionPerformed

    private void verHistorialActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_verHistorialActionPerformed
        // TODO add your handling code here:
        InterFechasVentas vGH = new InterFechasVentas();
        jDesktopPane_menu.add(vGH);
        vGH.setVisible(true);
    }//GEN-LAST:event_verHistorialActionPerformed

   
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuBar MenuWoowGames;
    private javax.swing.JMenu Menu_Categoria;
    private javax.swing.JMenu Menu_CerrarSesion;
    private javax.swing.JMenu Menu_Cliente;
    private javax.swing.JMenu Menu_Factura;
    private javax.swing.JMenu Menu_Historial;
    private javax.swing.JMenu Menu_Producto;
    private javax.swing.JMenu Menu_Reportes;
    private javax.swing.JMenu Menu_Usuario;
    private javax.swing.JMenuItem actualizarStock;
    private javax.swing.JMenuItem cerrarSesion;
    private javax.swing.JMenuItem gestionarCategoria;
    private javax.swing.JMenuItem gestionarCliente;
    private javax.swing.JMenuItem gestionarProducto;
    private javax.swing.JMenuItem gestionarUsuario;
    private javax.swing.JMenuItem gestionarVenta;
    private javax.swing.JMenuItem nuevaCategoria;
    private javax.swing.JMenuItem nuevaVenta;
    private javax.swing.JMenuItem nuevoCliente;
    private javax.swing.JMenuItem nuevoProducto;
    private javax.swing.JMenuItem nuevoUsuario;
    private javax.swing.JMenuItem reporteCategoria;
    private javax.swing.JMenuItem reporteCliente;
    private javax.swing.JMenuItem reporteProducto;
    private javax.swing.JMenuItem reporteVenta;
    private javax.swing.JMenuItem verHistorial;
    // End of variables declaration//GEN-END:variables
}
