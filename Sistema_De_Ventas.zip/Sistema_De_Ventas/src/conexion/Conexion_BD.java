package conexion;

import java.sql.Connection;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import java.sql.DriverManager;
/**
 *
 * @author jonat
 */
public class Conexion_BD {

    //Conexion Local 
    public static Connection conectar() {
        try {
            Connection cn = DriverManager.getConnection("jdbc:mysql://localhost/bd_sistema_ventas","root","SilverCloth50078");
            return cn;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error en la conexion local"+e);
        }
        return null;
    }
}
