-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema bd_sistema_ventas
-- -----------------------------------------------------
-- Diagrama UML relacional del proyecto sistema de ventas. Base de Datos ll
DROP SCHEMA IF EXISTS `bd_sistema_ventas` ;

-- -----------------------------------------------------
-- Schema bd_sistema_ventas
--
-- Diagrama UML relacional del proyecto sistema de ventas. Base de Datos ll
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `bd_sistema_ventas` ;
USE `bd_sistema_ventas` ;

-- -----------------------------------------------------
-- Table `bd_sistema_ventas`.`tb_usuario`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `bd_sistema_ventas`.`tb_usuario` ;

CREATE TABLE IF NOT EXISTS `bd_sistema_ventas`.`tb_usuario` (
  `idUsuario` INT(11) NOT NULL AUTO_INCREMENT,
  `nombre` VARCHAR(30) NOT NULL,
  `apellido` VARCHAR(30) NOT NULL,
  `usuario` VARCHAR(15) NOT NULL,
  `password` VARCHAR(15) NOT NULL,
  `telefono` VARCHAR(15) NOT NULL,
  `estado` INT(1) NOT NULL,
  PRIMARY KEY (`idUsuario`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `bd_sistema_ventas`.`tb_cliente`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `bd_sistema_ventas`.`tb_cliente` ;

CREATE TABLE IF NOT EXISTS `bd_sistema_ventas`.`tb_cliente` (
  `idCliente` INT(11) NOT NULL,
  `nombre` VARCHAR(30) NOT NULL,
  `apellido` VARCHAR(30) NOT NULL,
  `cedula` VARCHAR(15) NOT NULL,
  `telefono` VARCHAR(15) NOT NULL,
  `direccion` VARCHAR(100) NOT NULL,
  `estado` INT(1) NOT NULL,
  PRIMARY KEY (`idCliente`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `bd_sistema_ventas`.`tb_categoria`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `bd_sistema_ventas`.`tb_categoria` ;

CREATE TABLE IF NOT EXISTS `bd_sistema_ventas`.`tb_categoria` (
  `idCategoria` INT(11) NOT NULL,
  `descripcion` VARCHAR(200) NOT NULL,
  `estado` INT(1) NOT NULL,
  PRIMARY KEY (`idCategoria`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `bd_sistema_ventas`.`tb_producto`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `bd_sistema_ventas`.`tb_producto` ;

CREATE TABLE IF NOT EXISTS `bd_sistema_ventas`.`tb_producto` (
  `idProducto` INT(1) NOT NULL AUTO_INCREMENT,
  `nombre` VARCHAR(100) NOT NULL,
  `cantidad` INT(11) NOT NULL,
  `precio` DOUBLE(10,2) NOT NULL,
  `descripcion` VARCHAR(200) NOT NULL,
  `porcentajeIva` INT(2) NOT NULL,
  `idCategoria` INT(11) NOT NULL,
  `estado` INT(1) NOT NULL,
  PRIMARY KEY (`idProducto`),
  INDEX `idCateoria_idx` (`idCategoria` ASC) VISIBLE,
  CONSTRAINT `idCateoria`
    FOREIGN KEY (`idCategoria`)
    REFERENCES `bd_sistema_ventas`.`tb_categoria` (`idCategoria`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `bd_sistema_ventas`.`tb_cabecera_venta`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `bd_sistema_ventas`.`tb_cabecera_venta` ;

CREATE TABLE IF NOT EXISTS `bd_sistema_ventas`.`tb_cabecera_venta` (
  `idCabeceraVenta` INT(11) NOT NULL,
  `idCliente` INT(11) NOT NULL,
  `valorPagar` DOUBLE(10,2) NOT NULL,
  `fechaVenta` DATE NOT NULL,
  `estado` INT(1) NOT NULL,
  PRIMARY KEY (`idCabeceraVenta`),
  INDEX `idCliente_idx` (`idCliente` ASC) VISIBLE,
  CONSTRAINT `idCliente`
    FOREIGN KEY (`idCliente`)
    REFERENCES `bd_sistema_ventas`.`tb_cliente` (`idCliente`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `bd_sistema_ventas`.`tb_detalle_venta`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `bd_sistema_ventas`.`tb_detalle_venta` ;

CREATE TABLE IF NOT EXISTS `bd_sistema_ventas`.`tb_detalle_venta` (
  `idDetalleVenta` INT(11) NOT NULL,
  `idCabeceraVena` INT(11) NOT NULL,
  `idProducto` INT(11) NOT NULL,
  `cantidad` INT(11) NOT NULL,
  `precioUnitario` DOUBLE(10,2) NOT NULL,
  `subtotal` DOUBLE(10,2) NOT NULL,
  `descuento` DOUBLE(10,2) NOT NULL,
  `iva` DOUBLE(10,2) NOT NULL,
  `totalPagar` DOUBLE(10,2) NOT NULL,
  `estado` INT(1) NOT NULL,
  PRIMARY KEY (`idDetalleVenta`),
  INDEX `idCabeceraVenta_idx` (`idCabeceraVena` ASC) VISIBLE,
  INDEX `idProducto_idx` (`idProducto` ASC) VISIBLE,
  CONSTRAINT `idCabeceraVenta`
    FOREIGN KEY (`idCabeceraVena`)
    REFERENCES `bd_sistema_ventas`.`tb_cabecera_venta` (`idCabeceraVenta`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `idProducto`
    FOREIGN KEY (`idProducto`)
    REFERENCES `bd_sistema_ventas`.`tb_producto` (`idProducto`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
